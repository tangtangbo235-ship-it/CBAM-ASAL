import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def gaussian(window_size, sigma):
    gauss = torch.Tensor(
        [
            math.exp(-((x - window_size // 2) ** 2) / float(2 * sigma**2))
            for x in range(window_size)
        ]
    )
    return gauss / gauss.sum()


def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
    return window


def _ssim(img1, img2, window, window_size, channel, size_average=True):
    mu1 = F.conv2d(img1, window, padding=window_size // 2, groups=channel)
    mu2 = F.conv2d(img2, window, padding=window_size // 2, groups=channel)
    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2
    sigma1_sq = (
        F.conv2d(img1 * img1, window, padding=window_size // 2, groups=channel)
        - mu1_sq
    )
    sigma2_sq = (
        F.conv2d(img2 * img2, window, padding=window_size // 2, groups=channel)
        - mu2_sq
    )
    sigma12 = (
        F.conv2d(img1 * img2, window, padding=window_size // 2, groups=channel)
        - mu1_mu2
    )
    C1 = 0.01**2
    C2 = 0.03**2
    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / (
        (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
    )
    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)


class PureSSIMLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.window_size = 11
        self.channel = 1
        self.window = create_window(self.window_size, self.channel)

    def forward(self, pred, target):
        if self.window.device != pred.device:
            self.window = self.window.to(pred.device)
        ssim_val = _ssim(pred, target, self.window, self.window_size, self.channel)
        return 1 - ssim_val


class HybridLoss(nn.Module):
    def __init__(
        self, alpha=0.05, alpha_initial=0.15, use_adaptive=True, total_epochs=100
    ):
        super().__init__()
        self.alpha_target = alpha
        self.alpha_initial = alpha_initial
        self.use_adaptive = use_adaptive
        self.total_epochs = total_epochs
        self.current_epoch = 0
        self.mse = nn.MSELoss()
        self.window_size = 11
        self.channel = 1
        self.window = create_window(self.window_size, self.channel)

    def set_epoch(self, epoch):
        self.current_epoch = epoch

    def get_current_alpha(self):
        if not self.use_adaptive:
            return self.alpha_target
        progress = min(self.current_epoch / self.total_epochs, 1.0)
        cosine_decay = 0.5 * (1 + math.cos(math.pi * progress))
        alpha = self.alpha_target + (self.alpha_initial - self.alpha_target) * cosine_decay
        return alpha

    def forward(self, pred, target):
        if self.window.device != pred.device:
            self.window = self.window.to(pred.device)
        mse_loss = self.mse(pred, target)
        ssim_val = _ssim(pred, target, self.window, self.window_size, self.channel)
        alpha = self.get_current_alpha()
        return mse_loss + alpha * (1 - ssim_val)
