import torch
import torch.nn as nn
from models.cbam import CBAMBlock


class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(True),
        )

    def forward(self, x):
        return self.conv(x)


class UNetNoCBAM(nn.Module):
    def __init__(self):
        super().__init__()
        self.inc = DoubleConv(1, 32)
        self.down1 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(32, 64))
        self.down2 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(64, 128))
        self.down3 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(128, 256))
        self.down4 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(256, 512))
        self.up1 = nn.ConvTranspose2d(512, 256, 2, stride=2)
        self.conv_up1 = DoubleConv(512, 256)
        self.up2 = nn.ConvTranspose2d(256, 128, 2, stride=2)
        self.conv_up2 = DoubleConv(256, 128)
        self.up3 = nn.ConvTranspose2d(128, 64, 2, stride=2)
        self.conv_up3 = DoubleConv(128, 64)
        self.up4 = nn.ConvTranspose2d(64, 32, 2, stride=2)
        self.conv_up4 = DoubleConv(64, 32)
        self.outc = nn.Conv2d(32, 1, 1)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.conv_up1(torch.cat([self._pad(x4, self.up1(x5)), self.up1(x5)], 1))
        x = self.conv_up2(torch.cat([self._pad(x3, self.up2(x)), self.up2(x)], 1))
        x = self.conv_up3(torch.cat([self._pad(x2, self.up3(x)), self.up3(x)], 1))
        x = self.conv_up4(torch.cat([self._pad(x1, self.up4(x)), self.up4(x)], 1))
        return self.outc(x)

    @staticmethod
    def _pad(s, t):
        dy, dx = s.size(2) - t.size(2), s.size(3) - t.size(3)
        if dx > 0 or dy > 0:
            s = s[:, :, : t.size(2), : t.size(3)]
        return s


class AttentionUNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.inc = DoubleConv(1, 32)
        self.down1 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(32, 64))
        self.down2 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(64, 128))
        self.down3 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(128, 256))
        self.down4 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(256, 512))
        self.up1 = nn.ConvTranspose2d(512, 256, 2, stride=2)
        self.conv_up1 = DoubleConv(512, 256)
        self.up2 = nn.ConvTranspose2d(256, 128, 2, stride=2)
        self.conv_up2 = DoubleConv(256, 128)
        self.up3 = nn.ConvTranspose2d(128, 64, 2, stride=2)
        self.conv_up3 = DoubleConv(128, 64)
        self.up4 = nn.ConvTranspose2d(64, 32, 2, stride=2)
        self.conv_up4 = DoubleConv(64, 32)
        self.outc = nn.Conv2d(32, 1, 1)
        self.att1 = CBAMBlock(256)
        self.att2 = CBAMBlock(128)
        self.att3 = CBAMBlock(64)
        self.att4 = CBAMBlock(32)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.conv_up1(
            torch.cat([self.att1(self._pad(x4, self.up1(x5))), self.up1(x5)], 1)
        )
        x = self.conv_up2(
            torch.cat([self.att2(self._pad(x3, self.up2(x))), self.up2(x)], 1)
        )
        x = self.conv_up3(
            torch.cat([self.att3(self._pad(x2, self.up3(x))), self.up3(x)], 1)
        )
        x = self.conv_up4(
            torch.cat([self.att4(self._pad(x1, self.up4(x))), self.up4(x)], 1)
        )
        return self.outc(x)

    @staticmethod
    def _pad(s, t):
        dy, dx = s.size(2) - t.size(2), s.size(3) - t.size(3)
        if dx > 0 or dy > 0:
            s = s[:, :, : t.size(2), : t.size(3)]
        return s
