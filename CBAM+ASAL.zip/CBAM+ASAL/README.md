# Audio Denoising with CBAM-Enhanced UNet and Adaptive Hybrid Loss

A deep learning framework for audio denoising that combines a CBAM (Convolutional Block Attention Module) enhanced UNet architecture with an adaptive MSE+SSIM hybrid loss function. This project provides comprehensive comparisons against both traditional and state-of-the-art deep learning baselines.

## Features

- **CBAM-Enhanced UNet**: UNet architecture augmented with Channel Attention and Spatial Attention modules for improved feature selection
- **Adaptive Hybrid Loss**: Cosine-annealing scheduled combination of MSE and SSIM losses (α decays from 0.15 → 0.05)
- **Multiple Noise Types**: White, Pink, Brown, and Band-limited noise generation for training augmentation
- **Comprehensive Baselines**: Spectral Subtraction, ConvTasNet, MetricGAN+, DCCRN, FRCRN
- **Full Evaluation Suite**: SNR, SI-SDR, PESQ, STOI metrics with statistical analysis
- **Visualization**: Loss curves, spectrogram comparison, PSD analysis, scatter plots

## Project Structure

```
├── config.py                  # Global configuration (hyperparameters, paths, device)
├── train.py                   # Training entry point
├── evaluate.py                # Evaluation & visualization entry point
├── requirements.txt           # Python dependencies
├── .gitignore
│
├── models/                    # Neural network architectures
│   ├── __init__.py
│   ├── cbam.py                # CBAM attention mechanism (Channel + Spatial)
│   ├── unet.py                # UNet variants (with/without CBAM)
│   └── losses.py              # Loss functions (MSE, SSIM, Hybrid)
│
├── data/                      # Data loading & preprocessing
│   ├── __init__.py
│   ├── dataset.py             # AudioDataset class & data splitting
│   └── noise.py               # Noise generation functions
│
├── baselines/                 # Baseline model integrations
│   ├── __init__.py
│   ├── spectral_subtraction.py # Traditional spectral subtraction
│   └── load_baselines.py      # Deep learning baseline loaders
│
├── utils/                     # Utility functions
│   ├── __init__.py
│   ├── metrics.py             # Evaluation metrics (SNR, SI-SDR, PESQ, STOI)
│   ├── inference.py           # Model inference utilities
│   └── misc.py                # Miscellaneous helpers
│
├── visualization/             # Plotting & visualization
│   ├── __init__.py
│   └── plots.py               # All visualization functions
│
├── tools/                     # Auxiliary scripts
│   ├── scan_audio.py          # Scan & count audio files
│   └── extract_setup.py       # Extract experimental setup data
│
├── checkpoints/               # Model weights (gitignored)
└── results/                   # Evaluation outputs (gitignored)
```

## Installation

```bash
# Clone the repository
git clone https://github.com/your-username/audio-denoising-cbam-unet.git
cd audio-denoising-cbam-unet

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# Install dependencies
pip install -r requirements.txt
```

### Hardware Support

The framework automatically detects and uses the best available compute device:

1. **DirectML** (AMD/Intel GPUs via torch-directml) — highest priority
2. **CUDA** (NVIDIA GPUs)
3. **CPU** — fallback

## Data Preparation

Place your clean audio datasets in the following structure:

```
data/
├── music_clean/
│   └── archive/Data/          # GTZAN or similar music dataset
├── ambient_clean/             # Environmental sound recordings
└── speech_clean/              # Speech corpus (e.g., LibriSpeech)
```

Supported formats: `.wav`, `.flac`

The `AudioDataset` class automatically:
- Resamples all audio to 16 kHz
- Trims/pads to a fixed duration (default: 2 seconds)
- Adds synthetic noise at random SNR levels during training

## Usage

### Training

```bash
python train.py
```

This trains all ablation model variants:
- UNet without CBAM (MSE loss)
- UNet with CBAM (MSE loss)
- UNet with CBAM + Adaptive Hybrid Loss (Ours)

Model checkpoints are saved to `checkpoints/`.

### Evaluation

```bash
python evaluate.py
```

This performs:
- Full metrics evaluation across audio domains (Music, Speech, Ambient)
- Baseline model comparison (Spectral Subtraction, ConvTasNet, MetricGAN+, DCCRN, FRCRN)
- RTF & latency measurement
- Model complexity analysis (Params & FLOPs)
- Generates all visualization plots

Results are saved to `results/`.

### Auxiliary Tools

```bash
# Scan audio files and compute total duration
python tools/scan_audio.py

# Extract experimental setup statistics
python tools/extract_setup.py
```

## Model Architecture

### CBAM Attention Block

The Convolutional Block Attention Module applies sequential channel and spatial attention:

```
Input Feature → Channel Attention → Spatial Attention → Refined Feature
                    ↓                      ↓
              AvgPool + MaxPool      Conv7x7 + Sigmoid
              Shared MLP + Sigmoid
```

### UNet with CBAM

The encoder-decoder architecture with skip connections and CBAM blocks at each decoder level:

```
Encoder:  1→32→64→128→256→512 (MaxPool downsampling)
Decoder:  512→256→128→64→32→1 (TransposeConv upsampling + CBAM + skip)
```

### Adaptive Hybrid Loss

The loss function combines MSE and SSIM with cosine-annealing α scheduling:

```
L(x, ŷ) = α(t) · L_MSE(x, ŷ) + (1 - α(t)) · (1 - L_SSIM(x, ŷ))

α(t) = α* + (α₀ - α*) · ½(1 + cos(πt/T))
```

Where α* = 0.05 (target), α₀ = 0.15 (initial), T = total epochs.

## Evaluation Metrics

| Metric | Description | Range |
|--------|-------------|-------|
| SNR | Signal-to-Noise Ratio | Higher is better |
| SI-SDR | Scale-Invariant SDR | Higher is better |
| PESQ | Perceptual Evaluation of Speech Quality | 1.0 – 4.5 |
| STOI | Short-Time Objective Intelligibility | 0.0 – 1.0 |

## Citation

If you find this work useful, please cite:

```bibtex
@article{audio_denoising_cbam,
  title={Audio Denoising with CBAM-Enhanced UNet and Adaptive Hybrid Loss},
  author={Your Name},
  journal={Your Journal/Conference},
  year={2026}
}
```

## License

This project is licensed under the MIT License — see the LICENSE file for details.

## Acknowledgments

- [SpeechBrain](https://speechbrain.github.io/) — MetricGAN+ baseline
- [ModelScope](https://modelscope.cn/) — FRCRN baseline
- [ConvTasNet](https://arxiv.org/abs/1809.07454) — Conv-TasNet baseline
- [DCCRN](https://arxiv.org/abs/2008.00264) — DCCRN baseline
