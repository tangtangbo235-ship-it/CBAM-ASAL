import numpy as np
from pystoi import stoi as stoi_func
from pesq import pesq as pesq_func


def compute_bss_metrics(ref, est, sr=16000):
    if isinstance(ref, np.ndarray) is False:
        try:
            ref = ref.squeeze().cpu().detach().numpy()
        except Exception:
            pass
    if isinstance(est, np.ndarray) is False:
        try:
            est = est.squeeze().cpu().detach().numpy()
        except Exception:
            pass

    min_len = min(len(ref), len(est))
    ref, est = ref[:min_len], est[:min_len]
    EPS = 1e-10

    noise = ref - est
    snr = 10 * np.log10((np.sum(ref**2) + EPS) / (np.sum(noise**2) + EPS))

    alpha = np.dot(est, ref) / (np.dot(ref, ref) + EPS)
    e_target = alpha * ref
    e_res = est - e_target
    si_sdr = 10 * np.log10(
        (np.sum(e_target**2) + EPS) / (np.sum(e_res**2) + EPS)
    )

    try:
        pesq_score = pesq_func(sr, ref, est, "wb")
    except Exception:
        pesq_score = 1.05

    try:
        stoi_score = stoi_func(ref, est, sr, extended=False)
    except Exception:
        stoi_score = 0.0

    return {"SNR": snr, "SI-SDR": si_sdr, "PESQ": pesq_score, "STOI": stoi_score}
