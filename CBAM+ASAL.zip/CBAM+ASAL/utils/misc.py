import os
import sys
import json
import numpy as np
import scipy.signal
import torch


class SuppressPrint:
    def __enter__(self):
        self._original_stdout = sys.stdout
        sys.stdout = open(os.devnull, "w")

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout.close()
        sys.stdout = self._original_stdout


def rescue_baseline_waveform(pred, target):
    p = pred.squeeze().cpu().numpy()
    t = target.squeeze().cpu().numpy()

    p = p - np.mean(p)

    correlation = scipy.signal.correlate(t, p, mode="full")
    max_idx = np.argmax(np.abs(correlation))
    delay = max_idx - (len(p) - 1)
    is_inverted = correlation[max_idx] < 0

    if delay > 0:
        p_aligned = np.pad(p, (delay, 0), mode="constant")[: len(t)]
    elif delay < 0:
        p_aligned = np.pad(p[-delay:], (0, -delay), mode="constant")[: len(t)]
    else:
        p_aligned = p

    p_tensor = torch.from_numpy(p_aligned).to(pred.device).view(pred.shape)

    if is_inverted:
        p_tensor = -p_tensor

    if torch.max(torch.abs(p_tensor)) == 0:
        return p_tensor
    scale = torch.max(torch.abs(target)) / (torch.max(torch.abs(p_tensor)) + 1e-8)

    return p_tensor * scale


class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NumpyEncoder, self).default(obj)
