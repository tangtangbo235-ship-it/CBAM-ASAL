import os
import tempfile
import numpy as np
import torch
import torch.nn.functional as F
import soundfile as sf
from config import config


def inference_model(model, noisy_wav):
    noisy_wav = noisy_wav.cpu()
    if len(noisy_wav.shape) == 3:
        noisy_wav = noisy_wav.squeeze(1)
    if len(noisy_wav.shape) == 1:
        noisy_wav = noisy_wav.unsqueeze(0)

    win = torch.hann_window(512)
    stft = torch.stft(noisy_wav, 512, 128, 512, win, return_complex=True)
    mag, phase = stft.abs(), stft.angle()

    mag_in = torch.log1p(mag).unsqueeze(1)
    mag_in = mag_in[:, :, :-1, :]
    pad = 16 - (mag_in.shape[3] % 16)
    if pad < 16:
        mag_in = F.pad(mag_in, (0, pad))

    mag_in_gpu = mag_in.to(config.DEVICE)
    with torch.no_grad():
        pred_gpu = model(mag_in_gpu)
    pred = pred_gpu.cpu()

    if pad < 16:
        pred = pred[:, :, :, :-pad]
    pred = torch.expm1(F.pad(pred, (0, 0, 0, 1))).squeeze(1)
    rec = torch.istft(
        torch.complex(pred * torch.cos(phase), pred * torch.sin(phase)),
        512,
        128,
        512,
        win,
    )
    return rec


def modelscope_inference(pipeline_model, noisy_tensor):
    noisy_np = noisy_tensor.squeeze().cpu().numpy()

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        temp_path = f.name
    sf.write(temp_path, noisy_np, config.SAMPLE_RATE)

    try:
        result = pipeline_model(temp_path)
        out_pcm = result["output_pcm"]

        if isinstance(out_pcm, bytes):
            out_wav = np.frombuffer(out_pcm, dtype=np.int16).astype(np.float32) / 32768.0
        else:
            out_wav = out_pcm

        out_tensor = torch.from_numpy(out_wav).unsqueeze(0)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

    return out_tensor
