import os
import random
import math
import numpy as np
import torch
import torch.nn.functional as F
import torchaudio
import soundfile as sf
from torch.utils.data import Dataset, DataLoader

from config import config
from data.noise import get_random_noise


class AudioDataset(Dataset):
    def __init__(self, file_list, length_sec=2.0, is_simulated=False):
        self.file_list = file_list
        self.length = int(config.SAMPLE_RATE * length_sec)
        self.is_simulated = is_simulated
        if is_simulated:
            self.virtual_size = 500

    def __len__(self):
        return self.virtual_size if self.is_simulated else len(self.file_list)

    def _load_audio(self, path):
        data, sr = sf.read(path, dtype="float32")
        w = torch.from_numpy(data)
        if w.ndim == 1:
            w = w.unsqueeze(0)
        else:
            w = w.t()

        if sr != config.SAMPLE_RATE:
            w = torchaudio.functional.resample(
                w, orig_freq=sr, new_freq=config.SAMPLE_RATE
            )

        if w.shape[0] > 1:
            w = torch.mean(w, dim=0, keepdim=True)

        if w.shape[1] > self.length:
            start = random.randint(0, w.shape[1] - self.length)
            w = w[:, start : start + self.length]
        else:
            w = F.pad(w, (0, self.length - w.shape[1]))

        max_val = w.abs().max()
        if max_val > 0:
            w = w / (max_val + 1e-6)

        return w

    def _synth(self):
        t = torch.linspace(0, self.length / config.SAMPLE_RATE, self.length)
        sig = torch.zeros(self.length)
        num_freqs = random.randint(3, 5)
        for _ in range(num_freqs):
            f = random.uniform(220, 1200)
            amp = random.uniform(0.1, 0.3)
            sig += amp * torch.sin(2 * math.pi * f * t)
        return sig.unsqueeze(0)

    def __getitem__(self, idx):
        clean = self._synth() if self.is_simulated else self._load_audio(
            self.file_list[idx]
        )
        noise = get_random_noise(clean.shape)
        snr = random.uniform(0, 15)
        scale = torch.sqrt(
            clean.pow(2).mean() / (noise.pow(2).mean() * 10 ** (snr / 10) + 1e-8)
        )
        noisy = clean + noise * scale
        return noisy, clean


def get_split_files(seed):
    random.seed(seed)
    all_files = []
    for data_dir in config.DATA_DIRS:
        if os.path.exists(data_dir):
            for r, _, fs in os.walk(data_dir):
                for f in fs:
                    if f.endswith((".wav", ".mp3", ".flac")):
                        all_files.append(os.path.join(r, f))
    random.shuffle(all_files)
    n = len(all_files)
    if n == 0:
        return [], [], []
    n1, n2 = int(n * config.SPLIT_RATIO[0]), int(n * config.SPLIT_RATIO[1])
    return all_files[:n1], all_files[n1 : n1 + n2], all_files[n1 + n2 :]
