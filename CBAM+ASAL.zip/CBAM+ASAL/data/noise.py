import numpy as np
import torch
from config import config


def generate_white_noise(shape):
    return torch.randn(shape)


def generate_pink_noise(shape):
    n_samples = shape[1] if len(shape) > 1 else shape[0]
    white = torch.randn(n_samples)
    freqs = np.fft.rfftfreq(n_samples)
    pink_filter = 1.0 / (freqs + 1e-6)
    pink_filter[0] = 0
    pink_filter = pink_filter / np.sqrt(np.mean(pink_filter**2))
    pink = np.fft.irfft(np.fft.rfft(white.numpy()) * pink_filter, n=n_samples)
    return torch.from_numpy(pink).float().reshape(shape)


def generate_brown_noise(shape):
    n_samples = shape[1] if len(shape) > 1 else shape[0]
    white = torch.randn(n_samples)
    freqs = np.fft.rfftfreq(n_samples)
    brown_filter = 1.0 / (freqs**2 + 1e-6)
    brown_filter[0] = 0
    brown_filter = brown_filter / np.sqrt(np.mean(brown_filter**2))
    brown = np.fft.irfft(np.fft.rfft(white.numpy()) * brown_filter, n=n_samples)
    return torch.from_numpy(brown).float().reshape(shape)


def generate_band_limited_noise_1(shape, low_freq=200, high_freq=2000):
    n_samples = shape[1] if len(shape) > 1 else shape[0]
    white = torch.randn(n_samples)
    freqs = np.fft.rfftfreq(n_samples, 1 / config.SAMPLE_RATE)
    mask = (freqs >= low_freq) & (freqs <= high_freq)
    filtered = np.fft.rfft(white.numpy())
    filtered[~mask] = 0
    result = np.fft.irfft(filtered, n=n_samples)
    return torch.from_numpy(result).float().reshape(shape)


def generate_band_limited_noise_2(shape, low_freq=1000, high_freq=4000):
    n_samples = shape[1] if len(shape) > 1 else shape[0]
    white = torch.randn(n_samples)
    freqs = np.fft.rfftfreq(n_samples, 1 / config.SAMPLE_RATE)
    mask = (freqs >= low_freq) & (freqs <= high_freq)
    filtered = np.fft.rfft(white.numpy())
    filtered[~mask] = 0
    result = np.fft.irfft(filtered, n=n_samples)
    return torch.from_numpy(result).float().reshape(shape)


def get_random_noise(shape):
    import random

    noise_generators = [
        generate_white_noise,
        generate_pink_noise,
        generate_brown_noise,
        generate_band_limited_noise_1,
        generate_band_limited_noise_2,
    ]
    return random.choice(noise_generators)(shape)
