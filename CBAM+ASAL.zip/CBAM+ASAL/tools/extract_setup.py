import os
import wave

DATASET_ROOTS = [
    "./data/music_clean/archive/Data",
    "./data/ambient_clean",
    "./data/speech_clean",
]


def get_wav_info(filepath):
    try:
        with wave.open(filepath, "r") as wav_file:
            frames = wav_file.getnframes()
            rate = wav_file.getframerate()
            return frames / float(rate)
    except Exception:
        return 0.0


def scan_folder(folder_path):
    total_files = 0
    total_duration_sec = 0.0

    if not os.path.exists(folder_path):
        return 0, 0.0

    for root, _, files in os.walk(folder_path):
        for f in files:
            if f.endswith(".wav") or f.endswith(".flac"):
                total_files += 1
                total_duration_sec += get_wav_info(os.path.join(root, f))

    return total_files, total_duration_sec


def main():
    print(">>> Extracting experimental setup data...")

    roots = DATASET_ROOTS if isinstance(DATASET_ROOTS, list) else [DATASET_ROOTS]

    train_files, train_sec = 0, 0.0
    val_files, val_sec = 0, 0.0
    test_files, test_sec = 0, 0.0

    for root_dir in roots:
        t_f, t_s = scan_folder(os.path.join(root_dir, "train"))
        v_f, v_s = scan_folder(os.path.join(root_dir, "val"))
        te_f, te_s = scan_folder(os.path.join(root_dir, "test"))

        train_files += t_f
        train_sec += t_s
        val_files += v_f
        val_sec += v_s
        test_files += te_f
        test_sec += te_s

    train_hours = train_sec / 3600.0
    val_hours = val_sec / 3600.0
    test_hours = test_sec / 3600.0

    total_files = train_files + val_files + test_files
    total_hours = train_hours + val_hours + test_hours

    train_ratio = (train_files / total_files * 100) if total_files > 0 else 0
    val_ratio = (val_files / total_files * 100) if total_files > 0 else 0
    test_ratio = (test_files / total_files * 100) if total_files > 0 else 0

    report = f"""==================================================
Experimental Setup Raw Data
==================================================

[1. Dataset Details]
- Total Audio Files: {total_files} utterances
- Total Duration: {total_hours:.2f} hours
- Train Set: {train_files} utterances ({train_hours:.2f} hrs)  -> {train_ratio:.1f}%
- Val Set:   {val_files} utterances ({val_hours:.2f} hrs)  -> {val_ratio:.1f}%
- Test Set:  {test_files} utterances ({test_hours:.2f} hrs)  -> {test_ratio:.1f}%

[2. Hyperparameter Settings]
- Max Epochs: 100 (with Early Stopping, patience=10)
- Batch Size: 8
- Initial Learning Rate: 0.001
- Optimizer: Adam (default beta1=0.9, beta2=0.999)
==================================================
"""

    print(report)
    with open("results/experimental_setup_raw.txt", "w", encoding="utf-8") as f:
        f.write(report)
    print("Saved: results/experimental_setup_raw.txt")


if __name__ == "__main__":
    main()
