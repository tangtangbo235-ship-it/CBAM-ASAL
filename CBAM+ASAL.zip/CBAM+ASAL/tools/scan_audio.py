import os
import wave

DATASET_PATHS = [
    "./data",
]


def get_wav_duration(filepath):
    try:
        with wave.open(filepath, "r") as wav_file:
            return wav_file.getnframes() / float(wav_file.getframerate())
    except Exception:
        return 0.0


def main():
    print(">>> Scanning audio files...")
    total_files = 0
    total_duration_sec = 0.0

    paths_to_scan = DATASET_PATHS if isinstance(DATASET_PATHS, list) else [DATASET_PATHS]

    for path in paths_to_scan:
        if not os.path.exists(path):
            print(f"Warning: path not found -> {path}")
            continue

        print(f"Scanning: {path} ...")
        for root, _, files in os.walk(path):
            for file in files:
                if file.endswith(".wav") or file.endswith(".flac"):
                    total_files += 1
                    filepath = os.path.join(root, file)
                    total_duration_sec += get_wav_duration(filepath)

    print("\n" + "=" * 50)
    print("Scan Complete!")
    print(f"Total audio files: {total_files}")
    print(f"Total duration: {total_duration_sec / 3600:.2f} hours")
    print("=" * 50)


if __name__ == "__main__":
    main()
