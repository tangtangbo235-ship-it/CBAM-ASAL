import os
import sys
import types
import torch
import torch.nn as nn
import numpy as np
from config import config


def _patch_speechbrain():
    import speechbrain.utils.importutils

    _original_ensure = speechbrain.utils.importutils.LazyModule.ensure_module

    def _safe_ensure(self, stacklevel=1):
        try:
            return _original_ensure(self, stacklevel)
        except Exception:
            dummy = types.ModuleType(self.target)
            dummy.__path__ = []
            self.lazy_module = dummy
            self.loaded = True
            return dummy

    speechbrain.utils.importutils.LazyModule.ensure_module = _safe_ensure


def _patch_lstm_for_numpy():
    _orig_lstm = nn.LSTM.__init__

    def _safe_lstm(self, *args, **kwargs):
        safe_args = [
            int(a) if isinstance(a, (np.integer, np.int64)) else a for a in args
        ]
        safe_kwargs = {
            k: int(v) if isinstance(v, (np.integer, np.int64)) else v
            for k, v in kwargs.items()
        }
        _orig_lstm(self, *safe_args, **safe_kwargs)

    nn.LSTM.__init__ = _safe_lstm


def load_metricgan_plus():
    from speechbrain.inference.enhancement import SpectralMaskEnhancement

    _patch_speechbrain()
    model = SpectralMaskEnhancement.from_hparams(
        source="speechbrain/metricgan-plus-voicebank",
        savedir="pretrained_models/metricgan-plus-voicebank",
        run_opts={"device": "cuda" if torch.cuda.is_available() else "cpu"},
    )
    return model


def load_convtasnet():
    from asteroid.models import ConvTasNet

    model = ConvTasNet.from_pretrained(
        "JorisCos/ConvTasNet_Libri1Mix_enhsingle_16k"
    ).to(config.DEVICE)
    model.eval()
    return model


def load_dccrn():
    _patch_lstm_for_numpy()
    from asteroid.models import DCCRNet

    model = DCCRNet.from_pretrained(
        "JorisCos/DCCRNet_Libri1Mix_enhsingle_16k"
    ).to(config.DEVICE)
    model.eval()
    return model


def load_frcrn():
    from modelscope.pipelines import pipeline
    from modelscope.utils.constant import Tasks

    model = pipeline(
        Tasks.acoustic_noise_suppression, model="damo/speech_frcrn_ans_cirm_16k"
    )
    return model


def load_all_baselines(models_dict):
    print(">>> Loading MetricGAN+...")
    try:
        models_dict["MetricGAN+"] = load_metricgan_plus()
    except Exception as e:
        print(f"Warning: MetricGAN+ loading failed: {e}")

    print(">>> Loading ConvTasNet...")
    try:
        models_dict["ConvTasNet"] = load_convtasnet()
    except Exception as e:
        print(f"Warning: ConvTasNet loading failed: {e}")

    print(">>> Loading DCCRN...")
    try:
        models_dict["DCCRN"] = load_dccrn()
    except Exception as e:
        print(f"Warning: DCCRN loading failed: {e}")

    print(">>> Loading FRCRN...")
    try:
        models_dict["FRCRN"] = load_frcrn()
    except ImportError:
        print("Warning: modelscope not installed. Run: pip install modelscope")
    except Exception as e:
        print(f"Warning: FRCRN loading failed: {e}")

    return models_dict
