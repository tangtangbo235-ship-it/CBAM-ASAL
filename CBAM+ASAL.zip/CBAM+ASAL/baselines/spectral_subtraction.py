import torch
import torch.nn.functional as F
from config import config


def spectral_subtraction(noisy_wav, n_fft=512, hop_length=128):
    noisy_wav = noisy_wav.cpu()
    if len(noisy_wav.shape) == 1:
        noisy_wav = noisy_wav.unsqueeze(0)
    window = torch.hann_window(n_fft)

    stft = torch.stft(
        noisy_wav, n_fft, hop_length, n_fft, window, return_complex=True
    )
    mag, phase = torch.abs(stft), torch.angle(stft)

    mag = mag[:, :-1, :]
    phase = phase[:, :-1, :]

    noise_est = torch.mean(mag[:, :10], dim=1, keepdim=True)
    alpha = 0.1
    mag_enhanced = mag - alpha * noise_est

    floor_ratio = 0.5
    mag_enhanced = torch.maximum(mag_enhanced, floor_ratio * mag)
    mag_enhanced = torch.clamp(mag_enhanced, min=0.0)

    mag_enhanced = F.pad(mag_enhanced, (0, 0, 0, 1), mode="constant", value=0.0)
    phase = F.pad(phase, (0, 0, 0, 1), mode="constant", value=0.0)

    rec = torch.istft(
        torch.complex(
            mag_enhanced * torch.cos(phase), mag_enhanced * torch.sin(phase)
        ),
        n_fft,
        hop_length,
        n_fft,
        window,
    )

    if rec.shape[1] > noisy_wav.shape[1]:
        rec = rec[:, : noisy_wav.shape[1]]
    elif rec.shape[1] < noisy_wav.shape[1]:
        rec = F.pad(rec, (0, noisy_wav.shape[1] - rec.shape[1]))
    return rec
