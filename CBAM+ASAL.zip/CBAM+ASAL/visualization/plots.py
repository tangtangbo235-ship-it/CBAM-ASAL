import math
import numpy as np
import scipy.signal
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from tqdm import tqdm
from torch.utils.data import DataLoader

from config import config
from data.dataset import AudioDataset
from data.noise import get_random_noise
from baselines.spectral_subtraction import spectral_subtraction
from utils.metrics import compute_bss_metrics
from utils.inference import inference_model
from utils.misc import SuppressPrint


def plot_loss_curves(histories):
    model_name = "UNet with CBAM + SSIM (Ours)"

    if "cbam_ssim" not in histories or histories["cbam_ssim"] is None:
        print("Warning: no cbam_ssim training history, skipping")
        return

    history = histories["cbam_ssim"]
    epochs = list(range(1, len(history["t"]) + 1))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

    ax1.plot(
        epochs, history["t"], "b-", linewidth=2.5, label="Training Loss",
        marker="o", markersize=4,
    )
    ax1.plot(
        epochs, history["v"], "r-", linewidth=2.5, label="Validation Loss",
        marker="s", markersize=4,
    )

    ax1.set_xlabel("Epoch", fontsize=16, fontweight="bold")
    ax1.set_ylabel("Loss", fontsize=16, fontweight="bold")
    ax1.set_title(
        f"Training and Validation Loss - {model_name}", fontsize=18, fontweight="bold"
    )
    ax1.legend(fontsize=14, loc="upper right")
    ax1.grid(True, linestyle="--", alpha=0.5)
    ax1.tick_params(axis="both", labelsize=13)

    if "alpha" in history and history["alpha"]:
        ax2.plot(
            epochs, history["alpha"], "g-", linewidth=2.5,
            label=r"$\alpha(t)$", marker="^", markersize=4,
        )
        ax2.axhline(
            y=0.05, color="r", linestyle="--", linewidth=2,
            label=r"Target $\alpha^* = 0.05$",
        )
        ax2.axhline(
            y=0.15, color="gray", linestyle=":", linewidth=2,
            label=r"Initial $\alpha_0 = 0.15$",
        )

        ax2.set_xlabel("Epoch", fontsize=16, fontweight="bold")
        ax2.set_ylabel(r"$\alpha$", fontsize=16, fontweight="bold")
        ax2.set_title(
            r"Adaptive $\alpha$ Scheduling (Cosine Annealing)",
            fontsize=18, fontweight="bold",
        )
        ax2.legend(fontsize=13, loc="upper right")
        ax2.grid(True, linestyle="--", alpha=0.5)
        ax2.set_ylim(0.03, 0.18)
        ax2.tick_params(axis="both", labelsize=13)

    plt.tight_layout()
    plt.savefig("loss_curves_ours.svg", bbox_inches="tight")
    print("Saved: loss_curves_ours.svg")


def plot_test_loss_comparison(avg_losses, std_losses):
    model_names = {
        "NoCBAM": "UNet without CBAM",
        "CBAM_MSE": "UNet with CBAM (MSE)",
        "CBAM_SSIM": "Ours (CBAM+SSIM)",
    }

    methods = ["NoCBAM", "CBAM_MSE", "CBAM_SSIM"]
    values = [avg_losses[m] for m in methods]
    errors = [std_losses[m] for m in methods]
    labels = [model_names[m] for m in methods]

    fig, ax = plt.subplots(figsize=(12, 8))

    colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]
    bars = ax.bar(
        range(len(methods)), values, yerr=errors, color=colors,
        alpha=0.8, capsize=8, edgecolor="black", linewidth=1.5,
    )

    for i, (bar, val, err) in enumerate(zip(bars, values, errors)):
        height = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2.0, height + err + 0.001,
            f"{val:.4f}+/-{err:.4f}", ha="center", va="bottom",
            fontsize=14, fontweight="bold",
        )

    ax.set_ylabel("Test Loss", fontsize=18, fontweight="bold")
    ax.set_title("Test Set Loss Comparison", fontsize=20, fontweight="bold")
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(labels, fontsize=14, rotation=15, ha="right")
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    ax.set_axisbelow(True)
    ax.tick_params(axis="y", labelsize=14)

    bars[2].set_edgecolor("red")
    bars[2].set_linewidth(3)

    plt.tight_layout()
    plt.savefig("test_loss_comparison.svg", bbox_inches="tight")
    print("Saved: test_loss_comparison.svg")


def plot_metrics_bar_chart(domain_results):
    if "Noisy" in domain_results:
        domain_results = {"Combined_Evaluation": domain_results}

    for domain_name, means in domain_results.items():
        metrics = ["SNR", "SI-SDR", "PESQ", "STOI"]
        methods = [
            "Noisy", "Spectral", "NoCBAM", "CBAM_MSE", "CBAM_SSIM_Only",
            "NoCBAM_SSIM_MSE", "ConvTasNet", "MetricGAN+", "FRCRN", "DCCRN",
            "CBAM_SSIM",
        ]
        method_names = [
            "Noisy", "Spec.", "NoCBAM", "CBAM(MSE)", "CBAM(SSIM)",
            "NoCBAM(Mix)", "ConvTasNet", "MetricGAN+", "FRCRN", "DCCRN", "Ours",
        ]
        colors = [
            "#7f7f7f", "#1f77b4", "#ff7f0e", "#9467bd", "#17becf",
            "#e377c2", "#2ca02c", "#8c564b", "#9467bd", "#2ca02c", "#d62728",
        ]

        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        axes = axes.flatten()

        for idx, metric in enumerate(metrics):
            ax = axes[idx]
            values = [np.mean(means[m][metric]) for m in methods]

            bars = ax.bar(
                method_names, values, color=colors, alpha=0.8,
                edgecolor="black", linewidth=1.5,
            )
            ax.set_title(f"{metric} Comparison", fontsize=16, fontweight="bold")
            ax.set_ylabel(metric, fontsize=14, fontweight="bold")
            ax.grid(axis="y", linestyle="--", alpha=0.5)
            ax.tick_params(axis="x", labelsize=13, rotation=15)
            ax.tick_params(axis="y", labelsize=12)

            for bar, val in zip(bars, values):
                height = bar.get_height()
                offset = 0.05 * abs(ax.get_ylim()[1] - ax.get_ylim()[0])
                y_pos = height + offset if height >= 0 else height - offset
                va = "bottom" if height >= 0 else "top"
                ax.text(
                    bar.get_x() + bar.get_width() / 2.0, y_pos, f"{val:.2f}",
                    ha="center", va=va, fontsize=12, fontweight="bold",
                )

            bars[-1].set_edgecolor("red")
            bars[-1].set_linewidth(3)

        plt.suptitle(
            f"Objective Metrics Evaluation - {domain_name}",
            fontsize=20, fontweight="bold", y=1.02,
        )
        plt.tight_layout()

        safe_name = (
            domain_name.replace(" ", "_").replace("/", "_")
            .replace("(", "").replace(")", "")
        )
        save_path = f"metrics_bar_chart_{safe_name}.svg"
        plt.savefig(save_path, bbox_inches="tight")
        print(f"Saved: {save_path}")


def plot_spec_residual_improved(test_files, models_dict):
    print("Generating: Logarithmic Residual Error Spectrogram...")

    sr = config.SAMPLE_RATE
    duration = 2.0
    t = torch.linspace(0, duration, int(sr * duration))

    f0, f1 = 200, 2000
    k = (f1 - f0) / duration
    A_chirp = 0.4
    s_chirp = A_chirp * torch.sin(2 * math.pi * (f0 * t + (k / 2) * t**2))

    harmonics = [(440, 0.3), (880, 0.2), (1320, 0.15), (1760, 0.1)]
    s_harm = torch.zeros_like(t)
    for f_i, A_i in harmonics:
        s_harm += A_i * torch.sin(2 * math.pi * f_i * t)

    clean_t = (s_chirp + s_harm).unsqueeze(0)

    target_snr = 15.0
    noise = torch.randn_like(clean_t)
    signal_power = torch.mean(clean_t**2)
    noise_power = torch.mean(noise**2)
    noise_scale = torch.sqrt(
        signal_power / (noise_power * 10 ** (target_snr / 10))
    )
    noisy_t = clean_t + noise * noise_scale

    actual_snr = compute_bss_metrics(clean_t, noisy_t)["SNR"]
    print(f"Synthetic signal: Chirp(200-2000Hz) + Harmonics(440/880/1320/1760Hz)")
    print(f"Target SNR: {target_snr} dB, Actual SNR: {actual_snr:.2f} dB")

    input_snr = actual_snr

    spec_out = spectral_subtraction(noisy_t)
    no_cbam_out = inference_model(models_dict["no_cbam"], noisy_t)
    cbam_mse_out = inference_model(models_dict["cbam_mse"], noisy_t)
    cbam_ssim_out = inference_model(models_dict["cbam_ssim"], noisy_t)

    def to_spec_db(wav):
        if isinstance(wav, torch.Tensor):
            wav = wav.detach().cpu()
        wav = wav.squeeze()
        win = torch.hann_window(512)
        stft = torch.stft(wav, 512, 128, 512, win, return_complex=True)
        mag = torch.abs(stft)
        mag_db = 20 * torch.log10(mag + 1e-10)
        result = mag_db.numpy()
        if result.ndim == 3:
            result = result.squeeze()
        return result

    def to_residual_db(enhanced_wav):
        if isinstance(enhanced_wav, torch.Tensor):
            enhanced_wav = enhanced_wav.detach().cpu()
        enhanced_wav = enhanced_wav.squeeze()
        clean_1d = clean_t.squeeze()

        min_len = min(len(enhanced_wav), len(clean_1d))
        enhanced_wav = enhanced_wav[:min_len]
        clean_1d = clean_1d[:min_len]

        win = torch.hann_window(512)
        enhanced_stft = torch.stft(enhanced_wav, 512, 128, 512, win, return_complex=True)
        clean_stft = torch.stft(clean_1d, 512, 128, 512, win, return_complex=True)

        residual = torch.abs(enhanced_stft - clean_stft)
        residual_db = 20 * torch.log10(residual + 1e-10)
        result = residual_db.numpy()
        if result.ndim == 3:
            result = result.squeeze()
        return result

    c_db = to_spec_db(clean_t)
    n_db = to_spec_db(noisy_t)
    s_res_db = to_residual_db(spec_out)
    ncb_res_db = to_residual_db(no_cbam_out)
    cbm_res_db = to_residual_db(cbam_mse_out)
    cbs_res_db = to_residual_db(cbam_ssim_out)

    VMIN, VMAX = -80, 0

    fig, axes = plt.subplots(3, 2, figsize=(14, 14), constrained_layout=True)

    data_list = [
        (c_db, "Clean Reference", "jet"),
        (n_db, f"Noisy Input (SNR={input_snr:.1f}dB)", "jet"),
        (s_res_db, "Spectral Subtraction (Residual)", "hot"),
        (ncb_res_db, "UNet (No CBAM) (Residual)", "hot"),
        (cbm_res_db, "UNet (CBAM) (Residual)", "hot"),
        (cbs_res_db, "Ours (CBAM+SSIM) (Residual)", "hot"),
    ]

    for i, ax in enumerate(axes.flat):
        data, title, cmap = data_list[i]
        im = ax.imshow(data, aspect="auto", origin="lower", vmin=VMIN, vmax=VMAX, cmap=cmap)
        ax.set_title(title, fontsize=15, fontweight="bold")
        ax.set_xticks([])
        if i % 2 == 0:
            ax.set_ylabel("Frequency (bins)", fontsize=13)
        ax.tick_params(axis="y", labelsize=11)

        if "Ours" in title:
            for spine in ax.spines.values():
                spine.set_edgecolor("red")
                spine.set_linewidth(3)

    cbar = fig.colorbar(
        im, ax=axes.ravel().tolist(), orientation="horizontal",
        fraction=0.046, pad=0.02, aspect=40,
    )
    cbar.set_label("Residual Error Magnitude (dB)", fontsize=15)
    cbar.ax.tick_params(labelsize=12)

    plt.suptitle(
        "Logarithmic Residual Error Spectrogram Comparison",
        fontsize=20, fontweight="bold", y=1.02,
    )

    save_path = "spec_comparison_improved.svg"
    plt.savefig(save_path, bbox_inches="tight")
    print(f"Saved: {save_path}")


def plot_single_sample_snr_comparison(train_files, models_dict):
    print("Generating: Single Sample SNR Comparison...")

    if not train_files:
        print("Warning: no training data, using synthetic signal")
        sr = 16000
        t = torch.linspace(0, 1, sr)
        clean_sig = (
            0.3 * torch.sin(2 * math.pi * 440 * t)
            + 0.2 * torch.sin(2 * math.pi * 880 * t)
            + 0.1 * torch.sin(2 * math.pi * 1200 * t)
        ).unsqueeze(0)
        noise = get_random_noise(clean_sig.shape)
        noisy_sig = clean_sig + noise
    else:
        train_ds = AudioDataset(train_files)
        train_loader = DataLoader(train_ds, 1, False)
        noisy_sig, clean_sig = next(iter(train_loader))
        noisy_sig = noisy_sig.squeeze(1)
        clean_sig = clean_sig.squeeze(1)

    spectral_out = spectral_subtraction(noisy_sig)
    no_cbam_out = inference_model(models_dict["no_cbam"], noisy_sig)
    cbam_mse_out = inference_model(models_dict["cbam_mse"], noisy_sig)
    cbam_ssim_out = inference_model(models_dict["cbam_ssim"], noisy_sig)

    L = min(
        clean_sig.shape[1], spectral_out.shape[1], no_cbam_out.shape[1],
        cbam_mse_out.shape[1], cbam_ssim_out.shape[1],
    )
    clean_sig, noisy_sig = clean_sig[:, :L], noisy_sig[:, :L]
    spectral_out, no_cbam_out = spectral_out[:, :L], no_cbam_out[:, :L]
    cbam_mse_out, cbam_ssim_out = cbam_mse_out[:, :L], cbam_ssim_out[:, :L]

    snr_noisy = compute_bss_metrics(clean_sig, noisy_sig)["SNR"]
    snr_spectral = compute_bss_metrics(clean_sig, spectral_out)["SNR"]
    snr_no_cbam = compute_bss_metrics(clean_sig, no_cbam_out)["SNR"]
    snr_cbam_mse = compute_bss_metrics(clean_sig, cbam_mse_out)["SNR"]
    snr_cbam_ssim = compute_bss_metrics(clean_sig, cbam_ssim_out)["SNR"]

    imp_spectral = snr_spectral - snr_noisy
    imp_no_cbam = snr_no_cbam - snr_noisy
    imp_cbam_mse = snr_cbam_mse - snr_noisy
    imp_cbam_ssim = snr_cbam_ssim - snr_noisy

    plt.figure(figsize=(18, 12))

    plt.subplot(2, 3, 1)
    plt.plot(clean_sig.squeeze().numpy()[:2000], "k-", linewidth=2, label="Clean")
    plt.plot(noisy_sig.squeeze().numpy()[:2000], "gray", linewidth=1.2, alpha=0.7, label="Noisy")
    plt.title(f"Clean vs Noisy (SNR={snr_noisy:.2f}dB)", fontsize=15, fontweight="bold")
    plt.xlabel("Sample", fontsize=13)
    plt.ylabel("Amplitude", fontsize=13)
    plt.legend(fontsize=12, loc="upper right")
    plt.grid(True, alpha=0.3)
    plt.tick_params(axis="both", labelsize=11)

    methods = [
        (spectral_out, snr_spectral, imp_spectral, "Spectral Sub.", "gray"),
        (no_cbam_out, snr_no_cbam, imp_no_cbam, "UNet without CBAM", "#1f77b4"),
        (cbam_mse_out, snr_cbam_mse, imp_cbam_mse, "UNet with CBAM (MSE)", "#ff7f0e"),
        (cbam_ssim_out, snr_cbam_ssim, imp_cbam_ssim, "Ours (CBAM+SSIM)", "#2ca02c"),
    ]

    for i, (enhanced, snr, imp, name, color) in enumerate(methods, start=2):
        plt.subplot(2, 3, i)
        plt.plot(clean_sig.squeeze().numpy()[:2000], "k-", linewidth=2, alpha=0.6, label="Clean")
        plt.plot(enhanced.squeeze().numpy()[:2000], color=color, linewidth=2, label=name)
        plt.title(f"{name}\nSNR={snr:.2f}dB (d={imp:+.2f}dB)", fontsize=14, fontweight="bold")
        plt.xlabel("Sample", fontsize=13)
        plt.ylabel("Amplitude", fontsize=13)
        plt.legend(fontsize=11, loc="upper right")
        plt.grid(True, alpha=0.3)
        plt.tick_params(axis="both", labelsize=11)
        if i == 5:
            for spine in plt.gca().spines.values():
                spine.set_edgecolor("red")
                spine.set_linewidth(2.5)

    plt.subplot(2, 3, 6)
    snr_values = [snr_noisy, snr_spectral, snr_no_cbam, snr_cbam_mse, snr_cbam_ssim]
    snr_labels = ["Noisy", "Spectral", "without CBAM", "with CBAM", "Ours"]
    colors_bar = ["gray", "gray", "#1f77b4", "#ff7f0e", "#2ca02c"]
    bars = plt.bar(
        range(5), snr_values, color=colors_bar, alpha=0.8,
        edgecolor="black", linewidth=1.5,
    )

    for i, (bar, val) in enumerate(zip(bars, snr_values)):
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2.0, height + 0.3,
            f"{val:.2f}", ha="center", va="bottom", fontsize=13, fontweight="bold",
        )

    plt.xticks(range(5), snr_labels, fontsize=12, rotation=15)
    plt.ylabel("SNR (dB)", fontsize=14, fontweight="bold")
    plt.title("SNR Comparison", fontsize=15, fontweight="bold")
    plt.grid(axis="y", linestyle="--", alpha=0.5)
    plt.tick_params(axis="y", labelsize=12)
    plt.ylim(4, 20)
    bars[4].set_edgecolor("red")
    bars[4].set_linewidth(3)

    plt.tight_layout()
    plt.savefig("single_sample_snr_comparison.svg", bbox_inches="tight")
    print("Saved: single_sample_snr_comparison.svg")


def test_complex_signal(models_dict, test_files=None):
    print("Generating: Complex Signal Test...")

    if not test_files:
        sr = 16000
        t = torch.linspace(0, 1, sr)
        clean_sig = (
            0.3 * torch.sin(2 * math.pi * 440 * t)
            + 0.2 * torch.sin(2 * math.pi * 880 * t)
            + 0.1 * torch.sin(2 * math.pi * 1200 * t)
        ).unsqueeze(0)
        noise = get_random_noise(clean_sig.shape)
        noisy_sig = clean_sig + noise
    else:
        test_ds = AudioDataset(test_files)
        test_loader = DataLoader(test_ds, 1, False)
        noisy_sig, clean_sig = next(iter(test_loader))
        noisy_sig = noisy_sig.squeeze(1)
        clean_sig = clean_sig.squeeze(1)

    spectral_out = spectral_subtraction(noisy_sig)
    no_cbam_out = inference_model(models_dict["no_cbam"], noisy_sig)
    cbam_mse_out = inference_model(models_dict["cbam_mse"], noisy_sig)
    cbam_ssim_out = inference_model(models_dict["cbam_ssim"], noisy_sig)

    L = min(
        clean_sig.shape[1], spectral_out.shape[1], no_cbam_out.shape[1],
        cbam_mse_out.shape[1], cbam_ssim_out.shape[1],
    )
    clean_sig, noisy_sig = clean_sig[:, :L], noisy_sig[:, :L]
    spectral_out, no_cbam_out = spectral_out[:, :L], no_cbam_out[:, :L]
    cbam_mse_out, cbam_ssim_out = cbam_mse_out[:, :L], cbam_ssim_out[:, :L]

    snr_noisy = compute_bss_metrics(clean_sig, noisy_sig)["SNR"]
    snr_spectral = compute_bss_metrics(clean_sig, spectral_out)["SNR"]
    snr_no_cbam = compute_bss_metrics(clean_sig, no_cbam_out)["SNR"]
    snr_cbam_mse = compute_bss_metrics(clean_sig, cbam_mse_out)["SNR"]
    snr_cbam_ssim = compute_bss_metrics(clean_sig, cbam_ssim_out)["SNR"]

    plt.figure(figsize=(14, 10))
    sigs = [clean_sig, noisy_sig, spectral_out, no_cbam_out, cbam_mse_out, cbam_ssim_out]
    titles = [
        "Clean (Multi-Freq)",
        f"Noisy (SNR={snr_noisy:.2f}dB)",
        f"Spectral Subtraction (SNR={snr_spectral:.2f}dB)",
        f"UNet without CBAM (SNR={snr_no_cbam:.2f}dB)",
        f"UNet with CBAM (SNR={snr_cbam_mse:.2f}dB)",
        f"Ours (SNR={snr_cbam_ssim:.2f}dB)",
    ]
    colors = ["g", "gray", "b", "orange", "cyan", "r"]

    for i in range(6):
        plt.subplot(3, 2, i + 1)
        plt.plot(sigs[i].squeeze().numpy()[:1000], colors[i], linewidth=1.5)
        plt.title(titles[i], fontsize=12, fontweight="bold")
        plt.grid(True, alpha=0.3)
        plt.xlabel("Sample", fontsize=10)
        plt.ylabel("Amplitude", fontsize=10)

    plt.tight_layout()
    plt.savefig("complex_signal_test.svg", bbox_inches="tight")
    print("Saved: complex_signal_test.svg")


def plot_additional_analysis(test_files, models_dict):
    print("Generating: Scatter Plot & PSD Analysis...")

    test_ds = AudioDataset(test_files)
    subset_indices = range(min(100, len(test_ds)))

    results = {
        "Input_SNR": [],
        "Spectral": [],
        "NoCBAM": [],
        "CBAM_MSE": [],
        "CBAM_SSIM": [],
    }

    avg_psd = {k: None for k in ["Clean", "Noisy", "Spectral", "CBAM_SSIM"]}
    psd_count = 0
    device = config.DEVICE

    with torch.no_grad():
        for i in tqdm(subset_indices, desc="Analyzing for Plots"):
            noisy, clean = test_ds[i]
            noisy = noisy.unsqueeze(0).to(device)
            clean = clean.unsqueeze(0)

            curr_input_snr = compute_bss_metrics(
                clean.squeeze(), noisy.cpu().squeeze()
            )["SNR"]
            results["Input_SNR"].append(curr_input_snr)

            spectral_wav = spectral_subtraction(noisy.cpu().squeeze(1))
            no_cbam_wav = inference_model(models_dict["no_cbam"], noisy)
            cbam_mse_wav = inference_model(models_dict["cbam_mse"], noisy)
            cbam_ssim_wav = inference_model(models_dict["cbam_ssim"], noisy)

            L = min(clean.shape[-1], spectral_wav.shape[-1])
            c = clean.cpu().squeeze()[:L].numpy()
            n = noisy.cpu().squeeze()[:L].numpy()
            s = spectral_wav.squeeze()[:L].numpy()
            ncb = no_cbam_wav.squeeze()[:L].numpy()
            cbm = cbam_mse_wav.squeeze()[:L].numpy()
            cbs = cbam_ssim_wav.squeeze()[:L].numpy()

            results["Spectral"].append(compute_bss_metrics(c, s)["SNR"] - curr_input_snr)
            results["NoCBAM"].append(compute_bss_metrics(c, ncb)["SNR"] - curr_input_snr)
            results["CBAM_MSE"].append(compute_bss_metrics(c, cbm)["SNR"] - curr_input_snr)
            results["CBAM_SSIM"].append(compute_bss_metrics(c, cbs)["SNR"] - curr_input_snr)

            if psd_count < 20:
                fs = config.SAMPLE_RATE

                def get_psd(sig):
                    f, Pxx = scipy.signal.welch(sig, fs, nperseg=1024)
                    return f, Pxx

                f_axis, p_clean = get_psd(c)
                _, p_noisy = get_psd(n)
                _, p_spec = get_psd(s)
                _, p_ours = get_psd(cbs)

                if avg_psd["Clean"] is None:
                    avg_psd["Clean"] = p_clean
                    avg_psd["Noisy"] = p_noisy
                    avg_psd["Spectral"] = p_spec
                    avg_psd["CBAM_SSIM"] = p_ours
                else:
                    avg_psd["Clean"] += p_clean
                    avg_psd["Noisy"] += p_noisy
                    avg_psd["Spectral"] += p_spec
                    avg_psd["CBAM_SSIM"] += p_ours
                psd_count += 1

    for k in avg_psd:
        if avg_psd[k] is not None:
            avg_psd[k] /= psd_count
            avg_psd[k] = 10 * np.log10(avg_psd[k] + 1e-10)

    plt.figure(figsize=(12, 8))

    colors = {
        "Spectral": "gray", "NoCBAM": "#1f77b4",
        "CBAM_MSE": "#ff7f0e", "CBAM_SSIM": "red",
    }
    labels = {
        "Spectral": "Spectral Subtraction", "NoCBAM": "UNet (No CBAM)",
        "CBAM_MSE": "UNet (CBAM)", "CBAM_SSIM": "Ours (CBAM+SSIM)",
    }
    markers = {
        "Spectral": "x", "NoCBAM": ".",
        "CBAM_MSE": "^", "CBAM_SSIM": "o",
    }

    x = np.array(results["Input_SNR"])

    for method in ["Spectral", "NoCBAM", "CBAM_MSE", "CBAM_SSIM"]:
        y = np.array(results[method])
        plt.scatter(
            x, y, alpha=0.6, s=40, c=colors[method],
            marker=markers[method], label=labels[method],
        )
        if len(x) > 1 and len(np.unique(x)) > 2:
            z = np.polyfit(x, y, 2)
            p = np.poly1d(z)
            x_trend = np.linspace(min(x), max(x), 100)
            plt.plot(x_trend, p(x_trend), linestyle="--", linewidth=2.5, c=colors[method])

    plt.xlabel("Input SNR (dB)", fontsize=16, fontweight="bold")
    plt.ylabel("SNR Improvement (dB)", fontsize=16, fontweight="bold")
    plt.title(
        "Denoising Performance: Input SNR vs. Improvement",
        fontsize=18, fontweight="bold",
    )
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend(fontsize=13)
    plt.tick_params(axis="both", labelsize=13)
    plt.tight_layout()
    plt.savefig("snr_improvement_scatter.svg")
    print("Saved: snr_improvement_scatter.svg")

    plt.figure(figsize=(12, 8))

    if avg_psd["Clean"] is not None:
        plt.plot(f_axis, avg_psd["Clean"], color="black", linewidth=2, label="Clean Reference")
        plt.plot(f_axis, avg_psd["Noisy"], color="lightgray", linewidth=1.5, label="Noisy Input")
        plt.plot(f_axis, avg_psd["Spectral"], color="green", linestyle="--", linewidth=2, label="Spectral Sub.")
        plt.plot(f_axis, avg_psd["CBAM_SSIM"], color="red", linewidth=2.5, label="Ours (CBAM+SSIM)")
        plt.xlim([0, 8000])
        plt.ylim([np.min(avg_psd["Clean"]) - 10, np.max(avg_psd["Clean"]) + 5])

    plt.xlabel("Frequency (Hz)", fontsize=16, fontweight="bold")
    plt.ylabel("Power Spectral Density (dB/Hz)", fontsize=16, fontweight="bold")
    plt.title("Average Frequency Response Analysis", fontsize=18, fontweight="bold")
    plt.legend(fontsize=13, loc="upper right")
    plt.grid(True, which="both", linestyle="--", alpha=0.5)
    plt.tick_params(axis="both", labelsize=13)
    plt.tight_layout()
    plt.savefig("psd_comparison.svg")
    print("Saved: psd_comparison.svg")
