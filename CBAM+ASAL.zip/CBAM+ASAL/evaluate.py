import os
import json
import copy
import random
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
from scipy import stats

from config import config
from models.unet import UNetNoCBAM, AttentionUNet
from models.losses import HybridLoss
from data.dataset import AudioDataset, get_split_files
from baselines.spectral_subtraction import spectral_subtraction
from baselines.load_baselines import load_all_baselines
from utils.metrics import compute_bss_metrics
from utils.inference import inference_model, modelscope_inference
from utils.misc import rescue_baseline_waveform, NumpyEncoder, SuppressPrint
from visualization.plots import (
    plot_metrics_bar_chart,
    plot_spec_residual_improved,
    plot_single_sample_snr_comparison,
    test_complex_signal,
    plot_additional_analysis,
    plot_test_loss_comparison,
)


def evaluate_models(test_files, models_dict):
    domain_files = {
        "Music (GTZAN)": [
            f for f in test_files if "music" in f.lower() or "gtzan" in f.lower()
        ],
        "Speech (LibriSpeech)": [
            f
            for f in test_files
            if "speech" in f.lower() or "libri" in f.lower() or "voice" in f.lower()
        ],
        "Ambient (ESC-50)": [
            f for f in test_files if "ambient" in f.lower() or "esc" in f.lower()
        ],
    }

    domain_results = {}
    plot_sample = None

    baseline_metricgan = models_dict.get("MetricGAN+")
    baseline_convtasnet = models_dict.get("ConvTasNet")
    baseline_dccrn = models_dict.get("DCCRN")
    baseline_frcrn = models_dict.get("FRCRN")

    for domain_name, files in domain_files.items():
        if not files:
            continue

        print(f"\n---> Evaluating domain: {domain_name} (samples: {len(files)})")
        test_ds = AudioDataset(files)
        test_loader = DataLoader(test_ds, 1, False)

        all_results = {
            "Noisy": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "Spectral": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "NoCBAM": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "CBAM_MSE": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "CBAM_SSIM_Only": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "NoCBAM_SSIM_MSE": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "CBAM_SSIM": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "ConvTasNet": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "MetricGAN+": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "DCCRN": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
            "FRCRN": {"SNR": [], "SI-SDR": [], "PESQ": [], "STOI": []},
        }

        with torch.no_grad():
            for idx, (noisy, clean) in enumerate(
                tqdm(
                    test_loader,
                    desc=f"Evaluating {domain_name}",
                    total=min(50, len(test_loader)),
                )
            ):
                if idx >= 50:
                    break

                noisy, clean = noisy.squeeze(1), clean.squeeze(1)

                spectral_wav = spectral_subtraction(noisy)
                no_cbam_wav = inference_model(models_dict["no_cbam"], noisy)
                cbam_mse_wav = inference_model(models_dict["cbam_mse"], noisy)
                cbam_ssim_wav = inference_model(models_dict["cbam_ssim"], noisy)
                cbam_ssim_only_wav = inference_model(
                    models_dict["cbam_ssim_only"], noisy
                )
                no_cbam_ssim_mse_wav = inference_model(
                    models_dict["no_cbam_ssim_mse"], noisy
                )

                L = min(
                    clean.shape[1],
                    noisy.shape[1],
                    spectral_wav.shape[1],
                    no_cbam_wav.shape[1],
                    cbam_mse_wav.shape[1],
                    cbam_ssim_wav.shape[1],
                    cbam_ssim_only_wav.shape[1],
                    no_cbam_ssim_mse_wav.shape[1],
                )

                c, n, s = clean[:, :L], noisy[:, :L], spectral_wav[:, :L]
                ncb = no_cbam_wav[:, :L]
                cbm = cbam_mse_wav[:, :L]
                cbs = cbam_ssim_wav[:, :L]
                cbs_only = cbam_ssim_only_wav[:, :L]
                ncb_mix = no_cbam_ssim_mse_wav[:, :L]

                m_n = compute_bss_metrics(c, n)
                m_s = compute_bss_metrics(c, s)
                m_ncb = compute_bss_metrics(c, ncb)
                m_cbm = compute_bss_metrics(c, cbm)
                m_cbs = compute_bss_metrics(c, cbs)
                m_cbs_only = compute_bss_metrics(c, cbs_only)
                m_ncb_mix = compute_bss_metrics(c, ncb_mix)

                for k in m_n:
                    all_results["Noisy"][k].append(m_n[k])
                for k in m_s:
                    all_results["Spectral"][k].append(m_s[k])
                for k in m_ncb:
                    all_results["NoCBAM"][k].append(m_ncb[k])
                for k in m_cbm:
                    all_results["CBAM_MSE"][k].append(m_cbm[k])
                for k in m_cbs:
                    all_results["CBAM_SSIM"][k].append(m_cbs[k])
                for k in m_cbs_only:
                    all_results["CBAM_SSIM_Only"][k].append(m_cbs_only[k])
                for k in m_ncb_mix:
                    all_results["NoCBAM_SSIM_MSE"][k].append(m_ncb_mix[k])

                if baseline_convtasnet is not None:
                    try:
                        ctn_out = baseline_convtasnet(noisy.to(config.DEVICE)).cpu()
                        L_base = min(c.shape[1], ctn_out.shape[1])
                        c_base, ctn = c[:, :L_base], ctn_out[:, :L_base]
                        ctn = rescue_baseline_waveform(ctn, c_base)
                        m_ctn = compute_bss_metrics(c_base, ctn)
                        for k in m_ctn:
                            all_results["ConvTasNet"][k].append(m_ctn[k])
                    except Exception:
                        pass

                if baseline_metricgan is not None:
                    try:
                        noisy_for_sb = noisy
                        if noisy_for_sb.dim() == 2:
                            noisy_for_sb = noisy_for_sb.unsqueeze(1)
                        mgn_out = baseline_metricgan.enhance_batch(
                            noisy_for_sb, lengths=torch.tensor([1.0])
                        ).squeeze(1)
                        L_base = min(c.shape[1], mgn_out.shape[1])
                        c_base, mgn = c[:, :L_base], mgn_out[:, :L_base]
                        mgn = rescue_baseline_waveform(mgn, c_base)
                        m_mgn = compute_bss_metrics(c_base, mgn)
                        for k in m_mgn:
                            all_results["MetricGAN+"][k].append(m_mgn[k])
                    except Exception:
                        try:
                            mgn_out = modelscope_inference(baseline_metricgan, noisy)
                            L_base = min(c.shape[1], mgn_out.shape[1])
                            c_base, mgn = c[:, :L_base], mgn_out[:, :L_base]
                            mgn = rescue_baseline_waveform(mgn, c_base)
                            m_mgn = compute_bss_metrics(c_base, mgn)
                            for k in m_mgn:
                                all_results["MetricGAN+"][k].append(m_mgn[k])
                        except Exception:
                            pass

                if baseline_dccrn is not None:
                    try:
                        dcc_out = baseline_dccrn(noisy.to(config.DEVICE)).cpu()
                        L_base = min(c.shape[1], dcc_out.shape[1])
                        c_base, dcc = c[:, :L_base], dcc_out[:, :L_base]
                        dcc = rescue_baseline_waveform(dcc, c_base)
                        m_dcc = compute_bss_metrics(c_base, dcc)
                        for k in m_dcc:
                            all_results["DCCRN"][k].append(m_dcc[k])
                    except Exception:
                        pass

                if baseline_frcrn is not None:
                    try:
                        frc_out = modelscope_inference(baseline_frcrn, noisy)
                        L_base = min(c.shape[1], frc_out.shape[1])
                        c_base, frc = c[:, :L_base], frc_out[:, :L_base]
                        frc = rescue_baseline_waveform(frc, c_base)
                        m_frc = compute_bss_metrics(c_base, frc)
                        for k in m_frc:
                            all_results["FRCRN"][k].append(m_frc[k])
                    except Exception:
                        pass

                if plot_sample is None and domain_name == "Speech (LibriSpeech)":
                    plot_sample = (c, n, s, ncb, cbm, cbs)

        domain_results[domain_name] = all_results

    return domain_results, plot_sample


def compute_test_loss(test_files, models_dict):
    test_ds = AudioDataset(test_files)
    test_loader = DataLoader(test_ds, 1, False)

    mse_criterion = nn.MSELoss().to(config.DEVICE)
    hybrid_criterion = HybridLoss(alpha=0.05, use_adaptive=False).to(config.DEVICE)

    test_losses = {"NoCBAM": [], "CBAM_MSE": [], "CBAM_SSIM": []}

    with torch.no_grad():
        for noisy, clean in test_loader:
            noisy, clean = noisy.squeeze(1), clean.squeeze(1)

            win = torch.hann_window(512)
            S_n = torch.stft(noisy, 512, 128, 512, win, return_complex=True)
            mag_n = torch.log1p(S_n.abs())[:, :-1, :]
            pad = 16 - (mag_n.shape[2] % 16)
            if pad < 16:
                mag_n = F.pad(mag_n, (0, pad))

            S_c = torch.stft(clean, 512, 128, 512, win, return_complex=True)
            mag_c = torch.log1p(S_c.abs())[:, :-1, :]
            if pad < 16:
                mag_c = F.pad(mag_c, (0, pad))

            mag_n_gpu = mag_n.unsqueeze(1).to(config.DEVICE)
            mag_c_gpu = mag_c.unsqueeze(1).to(config.DEVICE)

            test_losses["NoCBAM"].append(
                mse_criterion(models_dict["no_cbam"](mag_n_gpu), mag_c_gpu).item()
            )
            test_losses["CBAM_MSE"].append(
                mse_criterion(models_dict["cbam_mse"](mag_n_gpu), mag_c_gpu).item()
            )
            test_losses["CBAM_SSIM"].append(
                hybrid_criterion(models_dict["cbam_ssim"](mag_n_gpu), mag_c_gpu).item()
            )

    avg_losses = {k: np.mean(v) for k, v in test_losses.items()}
    std_losses = {k: np.std(v) for k, v in test_losses.items()}

    return avg_losses, std_losses


def measure_all_rtf(models_dict):
    print("\n" + "=" * 75)
    print("[RTF & Latency Measurement - SCI Standard]")
    print("=" * 75)

    log_lines = []
    log_lines.append(f"{'Model Structure':<22} | {'Latency (ms)':<15} | {'RTF':<10}")
    log_lines.append("-" * 75)

    audio_len_sec = 1.0
    device = config.DEVICE
    num_runs = 100

    dummy_unet_spec = torch.randn(1, 1, 256, 128).to(device)
    dummy_wav_1d = torch.randn(1, 16000).to(device)
    dummy_wav_2d = torch.randn(1, 1, 16000).to(device)
    dummy_metricgan_spec = torch.randn(1, 126, 257).to(device)

    dl_models = [
        "no_cbam", "cbam_mse", "cbam_ssim_only", "no_cbam_ssim_mse",
        "ConvTasNet", "MetricGAN+", "FRCRN", "DCCRN", "cbam_ssim",
    ]
    display_names = {
        "no_cbam": "1. UNet (No CBAM)",
        "cbam_mse": "2. UNet (CBAM_MSE)",
        "cbam_ssim_only": "3. UNet (CBAM_SSIM)",
        "no_cbam_ssim_mse": "4. UNet (NoCBAM_Mix)",
        "ConvTasNet": "5. ConvTasNet",
        "MetricGAN+": "6. MetricGAN+",
        "FRCRN": "7. FRCRN",
        "DCCRN": "8. DCCRN",
        "cbam_ssim": "9. Ours (CBAM+Mix)",
    }

    for name in dl_models:
        disp_name = display_names[name]

        if name not in models_dict:
            log_lines.append(f"{disp_name:<22} | {'N/A':<15} | {'N/A':<10}")
            continue

        model_obj = models_dict[name]
        actual_model = None
        dummy_in = None

        try:
            if name == "ConvTasNet":
                actual_model = model_obj
                dummy_in = dummy_wav_2d
            elif name == "MetricGAN+":
                class MetricGANWrapper(nn.Module):
                    def __init__(self, m):
                        super().__init__()
                        self.m = m

                    def forward(self, x):
                        return self.m(x, lengths=torch.tensor([1.0]).to(x.device))

                actual_model = MetricGANWrapper(model_obj.mods.enhance_model)
                dummy_in = dummy_metricgan_spec
            elif name == "FRCRN":
                actual_model = model_obj.model
                dummy_in = dummy_wav_1d
            elif name == "DCCRN":
                actual_model = model_obj
                dummy_in = dummy_wav_1d
            else:
                actual_model = model_obj
                dummy_in = dummy_unet_spec

            actual_model.eval()

            with torch.no_grad():
                for _ in range(10):
                    _ = actual_model(dummy_in)

            if torch.cuda.is_available():
                torch.cuda.synchronize()

            start_time = time.time()
            with torch.no_grad():
                for _ in range(num_runs):
                    _ = actual_model(dummy_in)

            if torch.cuda.is_available():
                torch.cuda.synchronize()
            end_time = time.time()

            avg_time_sec = (end_time - start_time) / num_runs
            avg_time_ms = avg_time_sec * 1000
            rtf = avg_time_sec / audio_len_sec

            log_lines.append(
                f"{disp_name:<22} | {avg_time_ms:>10.2f} ms    | {rtf:>6.4f}"
            )
        except Exception:
            log_lines.append(f"{disp_name:<22} | {'Error':<15} | {'Error':<10}")

    final_text = "\n".join(log_lines)
    print(final_text)

    with open(os.path.join("results", "rtf_measurements.txt"), "w", encoding="utf-8") as f:
        f.write(final_text)
        f.write(
            "\n\n* Note: Latency and RTF are measured on the neural network forward pass "
            "using 1-second audio segments. Results are averaged over 100 iterations "
            "after GPU warm-up, utilizing asynchronous synchronization for precision."
        )

    print("Saved: results/rtf_measurements.txt")


def calculate_params_and_flops(models_dict):
    from thop import profile

    print("\n" + "=" * 75)
    print("[Model Complexity Measurement (Params & FLOPs)]")
    print("=" * 75)

    log_lines = []
    log_lines.append(f"{'Model Structure':<22} | {'Params (M)':<12} | {'MACs/FLOPs (G)':<15}")
    log_lines.append("-" * 75)

    dummy_unet_spec = torch.randn(1, 1, 256, 128).to(config.DEVICE)
    dummy_wav_2d = torch.randn(1, 1, 16000).to(config.DEVICE)
    dummy_metricgan_spec = torch.randn(1, 126, 257).to(config.DEVICE)

    dl_models = [
        "no_cbam", "cbam_mse", "cbam_ssim_only", "no_cbam_ssim_mse",
        "cbam_ssim", "ConvTasNet", "MetricGAN+", "FRCRN", "DCCRN",
    ]
    display_names = {
        "no_cbam": "1. UNet (No CBAM)",
        "cbam_mse": "2. UNet (CBAM+MSE)",
        "cbam_ssim_only": "3. UNet (CBAM+SSIM)",
        "no_cbam_ssim_mse": "4. UNet (NoCBAM+Mix)",
        "cbam_ssim": "5. Ours (Adaptive Loss)",
        "ConvTasNet": "6. ConvTasNet",
        "MetricGAN+": "7. MetricGAN+",
        "FRCRN": "8. FRCRN",
        "DCCRN": "9. DCCRN",
    }

    academic_macs_fallback = {"FRCRN": "16.40G*", "DCCRN": "8.18G"}
    unet_family_keys = [
        "no_cbam", "cbam_mse", "cbam_ssim_only", "no_cbam_ssim_mse", "cbam_ssim",
    ]

    for name in dl_models:
        disp_name = display_names[name]

        if name not in models_dict:
            log_lines.append(f"{disp_name:<22} | {'N/A':<12} | {'N/A':<15}")
            continue

        model_obj = models_dict[name]

        try:
            actual_model = None
            dummy_in = None

            if name in unet_family_keys:
                actual_model = model_obj
                dummy_in = dummy_unet_spec
            elif name == "ConvTasNet":
                actual_model = model_obj
                dummy_in = dummy_wav_2d
            elif name == "MetricGAN+":
                class MetricGANWrapper(nn.Module):
                    def __init__(self, m):
                        super().__init__()
                        self.m = m

                    def forward(self, x):
                        return self.m(x, lengths=torch.tensor([1.0]).to(x.device))

                actual_model = MetricGANWrapper(model_obj.mods.enhance_model)
                dummy_in = dummy_metricgan_spec
            elif name in ["FRCRN", "DCCRN"]:
                actual_model = model_obj.model if name == "FRCRN" else model_obj
                dummy_in = None

            total_params = sum(p.numel() for p in actual_model.parameters())
            params_str = f"{total_params / 1e6:.2f}M"

            if dummy_in is not None:
                with SuppressPrint():
                    macs, _ = profile(actual_model, inputs=(dummy_in,), verbose=False)
                macs_str = f"{macs / 1e9:.2f}G"
            else:
                macs_str = academic_macs_fallback[name]

        except Exception:
            if name == "MetricGAN+":
                macs_str = "1.24G*"
            else:
                macs_str = "Error"
            params_str = f"{sum(p.numel() for p in actual_model.parameters()) / 1e6:.2f}M" if actual_model else "Error"

        log_lines.append(f"{disp_name:<22} | {params_str:<12} | {macs_str:<15}")

    final_text = "\n".join(log_lines)
    print(final_text)

    with open(
        os.path.join("results", "dl_models_complexity.txt"), "w", encoding="utf-8"
    ) as f:
        f.write(final_text)
        f.write(
            "\n\n* Note: MACs/FLOPs marked with (*) are empirically estimated or sourced "
            "from literature, as standard profilers (e.g., thop) fundamentally lack support "
            "for tracing native complex-valued tensors (torch.complex64) used in these "
            "specific state-of-the-art architectures."
        )

    print("Saved: results/dl_models_complexity.txt")


def print_and_save_results(domain_results):
    print_methods = [
        "Noisy", "Spectral", "NoCBAM", "CBAM_MSE", "CBAM_SSIM_Only",
        "NoCBAM_SSIM_MSE", "ConvTasNet", "MetricGAN+", "FRCRN", "DCCRN", "CBAM_SSIM",
    ]
    display_names = [
        "Noisy Input", "Spec. Sub.", "1.UNet(Base)", "2.UNet(CBAM+MSE)",
        "3.UNet(CBAM+SSIM)", "4.UNet(SSIM+MSE)", "ConvTasNet", "MetricGAN+",
        "FRCRN", "DCCRN", "5.Ours(All)",
    ]

    all_results_text = "Metrics Results (Mean & Raw Data)\n"
    all_results_text += "=" * 75 + "\n"

    for domain_name, models_data in domain_results.items():
        print(f"\n{'='*75}")
        print(f"Domain: {domain_name}")
        print(f"{'='*75}")

        all_results_text += f"\n{'='*75}\nDomain: {domain_name}\n{'='*75}\n"

        print(f"\nMean Performance:")
        print(
            f"{'Method':<18} | {'SNR (dB)':<10} | {'SI-SDR':<10} | {'PESQ':<8} | {'STOI':<8}"
        )
        print("-" * 75)

        all_results_text += f"\nMean Performance:\n"
        all_results_text += (
            f"{'Method':<18} | {'SNR (dB)':<10} | {'SI-SDR':<10} | {'PESQ':<8} | {'STOI':<8}\n"
        )
        all_results_text += "-" * 75 + "\n"

        for orig_m, disp_m in zip(print_methods, display_names):
            if orig_m in models_data:
                snr = np.mean(models_data[orig_m]["SNR"])
                sisdr = np.mean(models_data[orig_m]["SI-SDR"])
                pesq_val = np.mean(models_data[orig_m]["PESQ"])
                stoi_val = np.mean(models_data[orig_m]["STOI"])

                snr_str = f"{snr:>10.2f}" if snr > -50 else "  <-50.00"
                sisdr_str = f"{sisdr:>10.2f}" if sisdr > -50 else "  <-50.00"

                row_str = f"{disp_m:<18} | {snr_str} | {sisdr_str} | {pesq_val:>8.2f} | {stoi_val:>8.4f}"
                print(row_str)
                all_results_text += row_str + "\n"

        print(f"\nRaw Data:")
        print("-" * 75)
        all_results_text += f"\nRaw Data:\n" + "-" * 75 + "\n"

        for orig_m, disp_m in zip(print_methods, display_names):
            if orig_m in models_data:
                print(f">>> {disp_m}:")
                all_results_text += f">>> {disp_m}:\n"

                def format_raw(lst, decimals=2):
                    return "[" + ", ".join([f"{x:.{decimals}f}" for x in lst]) + "]"

                snr_raw = f"   SNR    : {format_raw(models_data[orig_m]['SNR'], 2)}"
                sisdr_raw = f"   SI-SDR : {format_raw(models_data[orig_m]['SI-SDR'], 2)}"
                pesq_raw = f"   PESQ   : {format_raw(models_data[orig_m]['PESQ'], 2)}"
                stoi_raw = f"   STOI   : {format_raw(models_data[orig_m]['STOI'], 4)}"

                print(snr_raw)
                print(sisdr_raw)
                print(pesq_raw)
                print(stoi_raw + "\n")

                all_results_text += snr_raw + "\n"
                all_results_text += sisdr_raw + "\n"
                all_results_text += pesq_raw + "\n"
                all_results_text += stoi_raw + "\n\n"

    with open(
        os.path.join("results", "full_metrics_results.txt"), "w", encoding="utf-8"
    ) as f:
        f.write(all_results_text)
    print("Saved: results/full_metrics_results.txt")


def main():
    RECOMPUTE_METRICS = False
    RECOMPUTE_LOSS = False
    RUN_SCATTER_PSD = False

    DRAW_BAR_CHART = True
    DRAW_SPEC = True
    DRAW_SINGLE_SNR = True
    DRAW_COMPLEX_SIG = True

    metrics_cache_file = "cache_domain_results.json"
    losses_cache_file = "cache_test_losses.json"

    seed = 100
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    train_files, val_files, test_files = get_split_files(seed)

    if not test_files:
        print("Error: no test data found!")
        return

    models_dict = {}

    model_paths = {
        "no_cbam": os.path.join("checkpoints", "best_model_no_cbam.pth"),
        "cbam_mse": os.path.join("checkpoints", "best_model_cbam_mse.pth"),
        "cbam_ssim": os.path.join("checkpoints", "best_model_cbam_ssim.pth"),
        "cbam_ssim_only": os.path.join("checkpoints", "best_model_cbam_ssim_only.pth"),
        "no_cbam_ssim_mse": os.path.join("checkpoints", "best_model_no_cbam_ssim_mse.pth"),
    }

    print(">>> Loading trained models...")
    model_no_cbam = UNetNoCBAM().to(config.DEVICE)
    if os.path.exists(model_paths["no_cbam"]):
        model_no_cbam.load_state_dict(
            torch.load(model_paths["no_cbam"], map_location=config.DEVICE, weights_only=False)
        )
    model_no_cbam.eval()
    models_dict["no_cbam"] = model_no_cbam

    model_cbam_mse = AttentionUNet().to(config.DEVICE)
    if os.path.exists(model_paths["cbam_mse"]):
        model_cbam_mse.load_state_dict(
            torch.load(model_paths["cbam_mse"], map_location=config.DEVICE, weights_only=False)
        )
    model_cbam_mse.eval()
    models_dict["cbam_mse"] = model_cbam_mse

    model_cbam_ssim = AttentionUNet().to(config.DEVICE)
    if os.path.exists(model_paths["cbam_ssim"]):
        model_cbam_ssim.load_state_dict(
            torch.load(model_paths["cbam_ssim"], map_location=config.DEVICE, weights_only=False)
        )
    model_cbam_ssim.eval()
    models_dict["cbam_ssim"] = model_cbam_ssim

    model_cbam_ssim_only = AttentionUNet().to(config.DEVICE)
    if os.path.exists(model_paths["cbam_ssim_only"]):
        model_cbam_ssim_only.load_state_dict(
            torch.load(model_paths["cbam_ssim_only"], map_location=config.DEVICE, weights_only=False)
        )
    model_cbam_ssim_only.eval()
    models_dict["cbam_ssim_only"] = model_cbam_ssim_only

    model_no_cbam_ssim_mse = UNetNoCBAM().to(config.DEVICE)
    if os.path.exists(model_paths["no_cbam_ssim_mse"]):
        model_no_cbam_ssim_mse.load_state_dict(
            torch.load(model_paths["no_cbam_ssim_mse"], map_location=config.DEVICE, weights_only=False)
        )
    model_no_cbam_ssim_mse.eval()
    models_dict["no_cbam_ssim_mse"] = model_no_cbam_ssim_mse

    load_all_baselines(models_dict)

    if RECOMPUTE_METRICS:
        seeds_to_test = [42, 2026, 8888]
        print(f">>> Running {len(seeds_to_test)} seed evaluations...")

        accumulated_results = {}
        for i, s in enumerate(seeds_to_test):
            print(f"\nRunning seed {i+1}/{len(seeds_to_test)} (Seed: {s})")
            random.seed(s)
            np.random.seed(s)
            torch.manual_seed(s)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(s)

            current_domain_results, _ = evaluate_models(test_files, models_dict)

            if not accumulated_results:
                accumulated_results = copy.deepcopy(current_domain_results)
            else:
                for dom in current_domain_results:
                    for meth in current_domain_results[dom]:
                        if meth in accumulated_results[dom]:
                            for met in current_domain_results[dom][meth]:
                                accumulated_results[dom][meth][met].extend(
                                    current_domain_results[dom][meth][met]
                                )

        with open(metrics_cache_file, "w") as f:
            json.dump(accumulated_results, f, indent=4, cls=NumpyEncoder)
        print("Metrics computation complete. Cached.")
        domain_results = accumulated_results
    else:
        if os.path.exists(metrics_cache_file):
            print("Loading cached metrics...")
            with open(metrics_cache_file, "r") as f:
                domain_results = json.load(f)
        else:
            print("No cache found. Running evaluation...")
            domain_results, _ = evaluate_models(test_files, models_dict)

    if RECOMPUTE_LOSS:
        print("Computing test losses...")
        avg_losses, std_losses = compute_test_loss(test_files, models_dict)
        with open(losses_cache_file, "w") as f:
            json.dump({"avg": avg_losses, "std": std_losses}, f, indent=4, cls=NumpyEncoder)
    else:
        if os.path.exists(losses_cache_file):
            with open(losses_cache_file, "r") as f:
                loss_data = json.load(f)
                avg_losses, std_losses = loss_data["avg"], loss_data["std"]
        else:
            avg_losses, std_losses = {}, {}

    if RUN_SCATTER_PSD:
        plot_additional_analysis(test_files, models_dict)

    print("\n>>> Rendering plots...")

    if DRAW_BAR_CHART and domain_results:
        plot_metrics_bar_chart(domain_results)
        print_and_save_results(domain_results)

    if DRAW_SPEC:
        plot_spec_residual_improved(test_files, models_dict)

    if DRAW_SINGLE_SNR:
        plot_single_sample_snr_comparison(train_files, models_dict)

    if DRAW_COMPLEX_SIG:
        test_complex_signal(models_dict, test_files)

    measure_all_rtf(models_dict)
    calculate_params_and_flops(models_dict)

    print(f"\n{'='*60}")
    print("Evaluation complete! Results saved to ./results/")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
