"""
Demo inference script for CBAM-ASAL audio denoising.
Reviewers can upload their own audio files to get denoised results.

Usage:
    python demo_inference.py --input your_noisy_audio.wav --output denoised_output.wav

Requirements:
    - Input audio should be 16kHz sample rate (will be resampled if needed)
    - Supported input formats: .wav, .flac
    - Output format: .wav (always)
    - For .mp3/.m4a/.aac files, convert to .wav first
"""

import argparse
import os
import sys

import numpy as np
import torch
import soundfile as sf
from scipy.signal import resample_poly

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import config
from models.unet import AttentionUNet
from utils.inference import inference_model, load_state_dict_fp32


def load_audio(file_path, target_sr=16000):
    """Load audio file and resample to target sample rate if needed."""
    try:
        audio, sr = sf.read(file_path)
    except Exception as e:
        if file_path.lower().endswith((".mp3", ".m4a", ".aac", ".ogg")):
            print(f"\nError: '{file_path}' is in a compressed format not supported by soundfile.")
            print("Please convert it to .wav format first:")
            print("  pip install pydub")
            print("  python -c \"from pydub import AudioSegment; AudioSegment.from_file('input.mp3').export('output.wav', format='wav')\"")
            print("\nOr simply use a .wav file instead.")
        else:
            print(f"\nError opening audio file: {e}")
        sys.exit(1)

    # Convert stereo to mono
    if len(audio.shape) > 1:
        audio = audio.mean(axis=1)

    # Resample if necessary using scipy
    if sr != target_sr:
        audio = resample_poly(audio, target_sr, sr)
        print(f"Resampled from {sr}Hz to {target_sr}Hz")

    return audio.astype(np.float32)


def save_audio(file_path, audio, sr=16000):
    """Save audio file (always as WAV format)."""
    if not file_path.lower().endswith(".wav"):
        file_path = os.path.splitext(file_path)[0] + ".wav"
        print(f"Note: Output saved as WAV format: {file_path}")
    sf.write(file_path, audio, sr)
    print(f"Saved: {file_path}")


def main():
    parser = argparse.ArgumentParser(
        description="CBAM-ASAL Audio Denoising Demo",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Denoise a single file
    python demo_inference.py --input noisy.wav --output denoised.wav

    # Use specific model checkpoint (default: best_model_cbam_ssim.pth)
    python demo_inference.py --input noisy.wav --output denoised.wav --model checkpoints/best_model_cbam_ssim.pth
        """
    )
    parser.add_argument("--input", "-i", required=True, help="Path to input audio file")
    parser.add_argument("--output", "-o", required=True, help="Path to output audio file")
    parser.add_argument("--model", "-m", default="checkpoints/best_model_cbam_ssim.pth",
                        help="Path to model checkpoint (default: checkpoints/best_model_cbam_ssim.pth)")

    args = parser.parse_args()

    # Check input file exists
    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        return

    # Check model exists
    if not os.path.exists(args.model):
        print(f"Error: Model file not found: {args.model}")
        print("Available checkpoints:")
        for f in os.listdir("checkpoints"):
            print(f"  - {f}")
        return

    print(f"{'='*60}")
    print("CBAM-ASAL Audio Denoising Demo")
    print(f"{'='*60}")
    print(f"Input:  {args.input}")
    print(f"Output: {args.output}")
    print(f"Model:  {args.model}")
    print(f"Device: {config.DEVICE}")
    print(f"{'='*60}")

    # Load audio
    print("\nLoading audio...")
    audio = load_audio(args.input)
    print(f"Audio duration: {len(audio) / config.SAMPLE_RATE:.2f} seconds")

    # Load model
    print("\nLoading model...")
    model = AttentionUNet().to(config.DEVICE)
    model.load_state_dict(torch.load(args.model, map_location=config.DEVICE, weights_only=False))
    model.eval()
    print("Model loaded successfully!")

    # Prepare input tensor
    audio_tensor = torch.from_numpy(audio).unsqueeze(0)

    # Denoise
    print("\nDenoising...")
    with torch.no_grad():
        denoised_tensor = inference_model(model, audio_tensor)

    # Get denoised audio
    denoised_audio = denoised_tensor.squeeze().cpu().numpy()

    # Ensure output directory exists
    output_dir = os.path.dirname(args.output)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Save result
    save_audio(args.output, denoised_audio)

    print(f"\n{'='*60}")
    print("Denoising complete!")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
