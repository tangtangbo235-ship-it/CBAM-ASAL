import os
import random
import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
try:
    from tqdm import tqdm
except ImportError:
    def tqdm(iterable, **kwargs):
        return iterable

from config import config
from models.unet import UNetNoCBAM, AttentionUNet
from models.losses import PureSSIMLoss, HybridLoss
from data.dataset import AudioDataset, get_split_files


MODEL_NAMES = {
    "spectral": "Spectral Subtraction (Baseline)",
    "no_cbam": "UNet without CBAM (MSE only)",
    "cbam_mse": "UNet with CBAM (MSE only)",
    "cbam_ssim": "UNet with CBAM + SSIM (Ours)",
    "cbam_ssim_only": "UNet with CBAM (SSIM only)",
    "no_cbam_ssim_mse": "UNet without CBAM (SSIM+MSE)",
    "no_cbam_ssim_only": "UNet(Base+SSIM)",
}


def train_model(model_type, seed, run_idx):
    print(f"\n========== Training {MODEL_NAMES[model_type]} (Seed={seed}) ==========")
    train_files, val_files, test_files = get_split_files(seed)

    if not train_files:
        print("Warning: no data found!")
        return None, None, None

    train_ds = AudioDataset(train_files)
    val_ds = AudioDataset(val_files)
    train_loader = DataLoader(train_ds, config.BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, config.BATCH_SIZE, shuffle=False, num_workers=0)

    if model_type == "no_cbam":
        model = UNetNoCBAM().to(config.DEVICE)
        criterion = nn.MSELoss().to(config.DEVICE)
    elif model_type == "cbam_mse":
        model = AttentionUNet().to(config.DEVICE)
        criterion = nn.MSELoss().to(config.DEVICE)
    elif model_type == "cbam_ssim_only":
        model = AttentionUNet().to(config.DEVICE)
        criterion = PureSSIMLoss().to(config.DEVICE)
    elif model_type == "no_cbam_ssim_mse":
        model = UNetNoCBAM().to(config.DEVICE)
        criterion = HybridLoss(
            alpha=config.LOSS_ALPHA, alpha_initial=0.15,
            use_adaptive=True, total_epochs=config.MAX_EPOCHS,
        ).to(config.DEVICE)
    elif model_type == "no_cbam_ssim_only":
        model = UNetNoCBAM().to(config.DEVICE)
        criterion = PureSSIMLoss().to(config.DEVICE)
    else:
        model = AttentionUNet().to(config.DEVICE)
        criterion = HybridLoss(
            alpha=config.LOSS_ALPHA, alpha_initial=0.15,
            use_adaptive=True, total_epochs=config.MAX_EPOCHS,
        ).to(config.DEVICE)

    if model_type == "cbam_ssim_only":
        custom_lr = 0.0003
        optimizer = optim.Adam(
            model.parameters(), lr=custom_lr, weight_decay=1e-5, amsgrad=True
        )
        print(f"[Strategy] {model_type}: AMSGrad optimizer, lr={custom_lr}")
    elif model_type == "no_cbam_ssim_mse":
        custom_lr = 0.0001
        optimizer = optim.AdamW(
            model.parameters(), lr=custom_lr, betas=(0.5, 0.999), weight_decay=1e-4
        )
        print(f"[Strategy] {model_type}: Low-momentum AdamW, lr={custom_lr}")
    elif model_type == "no_cbam_ssim_only":
        custom_lr = 0.0003
        optimizer = optim.Adam(
            model.parameters(), lr=custom_lr, weight_decay=1e-5, amsgrad=True
        )
        print(f"[Strategy] {model_type}: AMSGrad optimizer, lr={custom_lr}")
    else:
        optimizer = optim.Adam(model.parameters(), lr=config.LR)

    best_vl = float("inf")
    history = {"t": [], "v": [], "alpha": []}
    no_improve_epochs = 0

    print(
        f">>> Training (Max Epochs={config.MAX_EPOCHS}, "
        f"Early Stop Patience={config.EARLY_STOP_PATIENCE})..."
    )

    for epoch in range(config.MAX_EPOCHS):
        if model_type in ("cbam_ssim", "no_cbam_ssim_mse") and hasattr(criterion, "set_epoch"):
            criterion.set_epoch(epoch)
            current_alpha = criterion.get_current_alpha()
            history["alpha"].append(current_alpha)
        elif hasattr(criterion, "get_current_alpha"):
            history["alpha"].append(criterion.get_current_alpha())
        else:
            history["alpha"].append(config.LOSS_ALPHA)

        model.train()
        tl = 0
        for noisy, clean in tqdm(
            train_loader,
            desc=f"{MODEL_NAMES[model_type][:20]} | Ep {epoch+1}",
            leave=False,
        ):
            noisy, clean = noisy.squeeze(1), clean.squeeze(1)
            win = torch.hann_window(512)
            S_n = torch.stft(noisy, 512, 128, 512, win, return_complex=True)
            mag_n = torch.log1p(S_n.abs())[:, :-1, :]
            pad = 16 - (mag_n.shape[2] % 16)
            if pad < 16:
                mag_n = F.pad(mag_n, (0, pad))
            S_c = torch.stft(clean, 512, 128, 512, win, return_complex=True)
            mag_c = torch.log1p(S_c.abs())[:, :-1, :]
            if pad < 16:
                mag_c = F.pad(mag_c, (0, pad))

            mag_n_gpu = mag_n.unsqueeze(1).to(config.DEVICE)
            mag_c_gpu = mag_c.unsqueeze(1).to(config.DEVICE)

            optimizer.zero_grad()
            pred = model(mag_n_gpu)
            l = criterion(pred, mag_c_gpu)
            l.backward()
            optimizer.step()
            tl += l.item()

        tl /= len(train_loader)

        model.eval()
        vl = 0
        with torch.no_grad():
            for noisy, clean in val_loader:
                noisy, clean = noisy.squeeze(1), clean.squeeze(1)
                win = torch.hann_window(512)
                S_n = torch.stft(noisy, 512, 128, 512, win, return_complex=True)
                mag_n = torch.log1p(S_n.abs())[:, :-1, :]
                pad = 16 - (mag_n.shape[2] % 16)
                if pad < 16:
                    mag_n = F.pad(mag_n, (0, pad))
                S_c = torch.stft(clean, 512, 128, 512, win, return_complex=True)
                mag_c = torch.log1p(S_c.abs())[:, :-1, :]
                if pad < 16:
                    mag_c = F.pad(mag_c, (0, pad))

                mag_n_gpu = mag_n.unsqueeze(1).to(config.DEVICE)
                mag_c_gpu = mag_c.unsqueeze(1).to(config.DEVICE)
                vl += criterion(model(mag_n_gpu), mag_c_gpu).item()
        vl /= len(val_loader)

        history["t"].append(tl)
        history["v"].append(vl)
        alpha_str = (
            f" | alpha: {history['alpha'][-1]:.4f}"
            if model_type in ("cbam_ssim", "no_cbam_ssim_mse")
            else ""
        )
        print(
            f"{MODEL_NAMES[model_type][:20]} | Ep {epoch+1} | "
            f"T: {tl:.4f} | V: {vl:.4f}{alpha_str}"
        )

        if vl < best_vl:
            best_vl = vl
            no_improve_epochs = 0
            checkpoint_name = (
                f"best_model_{model_type}_seed{seed}.pth"
                if run_idx != 0
                else f"best_model_{model_type}.pth"
            )
            model_path = os.path.join("checkpoints", checkpoint_name)
            torch.save(model.state_dict(), model_path)
        else:
            no_improve_epochs += 1
            if no_improve_epochs >= config.EARLY_STOP_PATIENCE:
                print(f"Early stopping triggered at epoch {epoch+1}")
                break

    return history, test_files, model


def main():
    from visualization.plots import plot_loss_curves

    seed = 42
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)

    print(f"\n{'='*60}")
    print(f"Starting Ablation Experiments (Seed={seed})")
    print(f"{'='*60}")

    model_types = ["no_cbam", "cbam_mse", "cbam_ssim_only", "no_cbam_ssim_mse", "no_cbam_ssim_only", "cbam_ssim"]
    histories = {}
    models_dict = {}

    for model_type in model_types:
        history, test_files, model = train_model(model_type, seed, 0)
        histories[model_type] = history
        models_dict[model_type] = model

    plot_loss_curves(histories)

    print(f"\n{'='*60}")
    print("Training complete! Model checkpoints saved to ./checkpoints/")
    print(f"{'='*60}")

    return models_dict


if __name__ == "__main__":
    main()
