import os
import torch

try:
    import torch_directml
    has_dml = True
except ImportError:
    has_dml = False


class Config:
    SAMPLE_RATE = 16000
    N_FFT = 512
    HOP_LENGTH = 128
    WIN_LENGTH = 512

    BATCH_SIZE = 8
    MAX_EPOCHS = 100
    EARLY_STOP_PATIENCE = 10
    LR = 0.001
    LOSS_ALPHA = 0.05

    NUM_EXPERIMENTS = 1
    SPLIT_RATIO = [0.8, 0.1, 0.1]

    DATA_DIRS = [
        "./data/music_clean/archive/Data",
        "./data/ambient_clean",
        "./data/speech_clean",
    ]

    SAVE_MODEL_PATH = "./checkpoints/best_model_val.pth"

    def get_best_device():
        if has_dml and torch_directml.is_available():
            print("Detected DirectML (AMD/Intel GPU)")
            return torch_directml.device()
        if torch.cuda.is_available():
            return torch.device("cuda")
        return torch.device("cpu")

    DEVICE = get_best_device()


config = Config()
print(f"Running on: {config.DEVICE}")
