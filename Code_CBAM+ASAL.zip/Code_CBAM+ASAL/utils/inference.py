import os
import sys
import torch
import torch.nn.functional as F

_conda_dll_handle = None
if os.name == "nt" and hasattr(os, "add_dll_directory"):
    conda_dll_dir = os.path.join(sys.prefix, "Library", "bin")
    if os.path.isdir(conda_dll_dir):
        os.environ["PATH"] = conda_dll_dir + os.pathsep + os.environ.get("PATH", "")
        _conda_dll_handle = os.add_dll_directory(conda_dll_dir)

from config import config


def load_state_dict_fp32(path, device=None):
    """加载权重，自动将 fp16 转回 fp32，兼容 fp32 权重。
    用于读取为节省体积而保存为 fp16 的 checkpoint。"""
    if device is None:
        device = config.DEVICE
    sd = torch.load(path, map_location=device, weights_only=False)
    return {k: (v.float() if v.dtype == torch.float16 else v) for k, v in sd.items()}


def inference_model(model, noisy_wav):
    noisy_wav = noisy_wav.cpu()
    if len(noisy_wav.shape) == 3:
        noisy_wav = noisy_wav.squeeze(1)
    if len(noisy_wav.shape) == 1:
        noisy_wav = noisy_wav.unsqueeze(0)

    win = torch.hann_window(512)
    stft = torch.stft(noisy_wav, 512, 128, 512, win, return_complex=True)
    mag, phase = stft.abs(), stft.angle()

    mag_in = torch.log1p(mag).unsqueeze(1)
    mag_in = mag_in[:, :, :-1, :]
    pad = 16 - (mag_in.shape[3] % 16)
    if pad < 16:
        mag_in = F.pad(mag_in, (0, pad))

    mag_in_gpu = mag_in.to(config.DEVICE)
    with torch.no_grad():
        pred_gpu = model(mag_in_gpu)
    pred = pred_gpu.cpu()

    if pad < 16:
        pred = pred[:, :, :, :-pad]
    pred = torch.expm1(F.pad(pred, (0, 0, 0, 1))).squeeze(1)
    rec = torch.istft(
        torch.complex(pred * torch.cos(phase), pred * torch.sin(phase)),
        512,
        128,
        512,
        win,
    )
    return rec
